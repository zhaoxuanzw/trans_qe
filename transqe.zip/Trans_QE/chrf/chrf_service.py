import re
from collections import Counter

def compute_chrF(reference_text, hypothesis_text, n=6):
    """
    计算参考文本与候选文本之间的 chrF 分数。
    """
    def ngrams(tokens, n):
        return [tuple(tokens[i:i+n]) for i in range(len(tokens)-n+1)]

    def char_ngrams(s, n):
        s = re.sub(r'\s', '', s)  # remove whitespace
        return ngrams(s, n)

    def precision_recall_f1(reference, hypothesis, n):
        ref_ngrams = char_ngrams(reference, n)
        hyp_ngrams = char_ngrams(hypothesis, n)
        ref_count = Counter(ref_ngrams)
        hyp_count = Counter(hyp_ngrams)
        intersection = ref_count & hyp_count
        precision = sum(intersection.values()) / max(sum(hyp_count.values()), 1)
        recall = sum(intersection.values()) / max(sum(ref_count.values()), 1)
        f1_score = 2 * precision * recall / (precision + recall) if precision + recall > 0 else 0
        return precision, recall, f1_score

    avg_f1 = 0.0
    for i in range(1, n+1):
        _, _, f1 = precision_recall_f1(reference_text, hypothesis_text, i)
        avg_f1 += f1 / n
    return avg_f1
