from flask import Blueprint, request, jsonify
from .chrf_service import compute_chrF

# 创建 Blueprint 对象，URL 前缀为 /chrf
chrf_blueprint = Blueprint('chrf', __name__, url_prefix='/chrf')

@chrf_blueprint.route('/calculate', methods=['POST'])
def calculate_chrF_api():
    data = request.get_json()
    reference_text = data.get('reference_text')
    hypothesis_text = data.get('hypothesis_text')
    if not reference_text or not hypothesis_text:
        return jsonify({"error": "Both reference_text and hypothesis_text are required."}), 400
    chrf_score = compute_chrF(reference_text, hypothesis_text)
    return jsonify({"chrF_score": chrf_score})
