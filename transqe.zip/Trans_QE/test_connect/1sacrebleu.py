import requests
import json

# 定义 Flask 服务的 URL
BASE_URL = "http://127.0.0.1:5001/sacrebleu/calculate"

# 定义参考文本和候选文本
reference_text = "This is a test reference text."
candidate_text = "This is a test candidate text."

# 构建请求数据
data = {
    "reference": reference_text,
    "candidate": candidate_text
}

# 发送 POST 请求到 Flask 服务
response = requests.post(BASE_URL, json=data)

# 检查响应状态并输出结果
if response.status_code == 200:
    result = response.json()
    print("SacreBLEU Score:", result.get("sacrebleu_score"))
else:
    print(f"Error: {response.status_code} - {response.text}")
