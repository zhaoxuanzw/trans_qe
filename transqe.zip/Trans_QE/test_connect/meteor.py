import requests
import json

# 设置服务的 URL
url = 'http://127.0.0.1:5001/meteor/calculate'  # 根据实际部署的 URL 和端口号调整

# 测试数据
data = {
    "reference_text": "This is a reference text.",
    "hypothesis_text": "This is a hypothesis text."
}

# 发送 POST 请求
response = requests.post(url, json=data)

# 检查响应状态码
if response.status_code == 200:
    # 如果请求成功，解析 JSON 响应
    result = response.json()
    print(f"Meteor Score: {result.get('meteor_score')}")
else:
    # 如果请求失败，打印错误信息
    print(f"Error: {response.status_code}, {response.json().get('error')}")
