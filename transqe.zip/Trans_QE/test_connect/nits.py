# import requests

# # 定义服务的 URL
# BASE_URL = "http://127.0.0.1:5001/nist/calculate"

# # 定义参考文本和候选文本
# reference_text = "这是一个参考句子。"
# candidate_text = "这是一个候选句子。"

# # 构建请求数据
# data = {
#     "reference": reference_text,
#     "candidate": candidate_text
# }

# # 发送 POST 请求到 Flask 服务
# response = requests.post(BASE_URL, json=data)

# # 检查响应状态并输出结果
# if response.status_code == 200:
#     result = response.json()
#     print("NIST Score:", result.get("nist_score"))
# else:
#     print(f"Error: {response.status_code} - {response.text}")


import requests

# 定义服务的 URL
BASE_URL = "http://127.0.0.1:5001/nist/calculate"

# 十个参考文本和候选文本的组合
examples = [
    {"reference": "这是一个测试句子。", "candidate": "这是一个测试的句子。"},
    {"reference": "机器学习是一门非常有趣的学科。", "candidate": "机器学习是一个非常有趣的学科。"},
    {"reference": "今天的天气很好，阳光明媚。", "candidate": "今天阳光明媚，天气很好。"},
    {"reference": "Python 是一种非常流行的编程语言。", "candidate": "Python 是一种流行的编程语言。"},
    {"reference": "我喜欢去公园散步，呼吸新鲜空气。", "candidate": "我喜欢去公园散步，享受新鲜空气。"},
    {"reference": "科学技术是第一生产力。", "candidate": "科学技术是最重要的生产力。"},
    {"reference": "我今天中午吃了一碗面条。", "candidate": "今天中午我吃了碗面条。"},
    {"reference": "他是一位非常出色的医生。", "candidate": "他是一个非常棒的医生。"},
    {"reference": "明天我们计划去旅游。", "candidate": "我们明天计划去旅游。"},
    {"reference": "这部电影非常感人，值得一看。", "candidate": "这部电影感人至深，值得观看。"}
]

# 依次计算每一对参考文本和候选文本的 NIST 分数
for i, example in enumerate(examples, 1):
    data = {
        "reference": example["reference"],
        "candidate": example["candidate"]
    }

    # 发送 POST 请求到 Flask 服务
    response = requests.post(BASE_URL, json=data)

    # 检查响应状态并输出结果
    if response.status_code == 200:
        result = response.json()
        print(f"Example {i} - NIST Score:", result.get("nist_score"))
    else:
        print(f"Example {i} - Error: {response.status_code} - {response.text}")
