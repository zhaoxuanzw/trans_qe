import requests
import time
def read_file(file_path):
    """从指定文件读取文本内容并逐行返回"""
    with open(file_path, 'r', encoding='utf-8') as file:
        return file.readlines()  # 返回每一行的列表

def compute_comet_score(src_file, mt_file, ref_file, url='http://127.0.0.1:5001/comet_da/compute_comet_da'):
    """
    计算 COMET-QE 分数。
    
    :param src_file: 源文件路径
    :param mt_file: 机器翻译文件路径
    :param ref_file: 参考翻译文件路径
    :param url: 服务端 URL
    :return: COMET-QE 分数列表
    """
    # 逐行读取文件内容
    src_lines = read_file(src_file)
    mt_lines = read_file(mt_file)
    ref_lines = read_file(ref_file)

    if len(src_lines) != len(mt_lines) or len(mt_lines) != len(ref_lines):
        raise ValueError("源文件、机器翻译文件和参考翻译文件的行数不匹配")

    # 准备请求数据，逐行组合对应的源句子、机器翻译和参考翻译
    data = []
    for src, mt, ref in zip(src_lines, mt_lines, ref_lines):
        data.append({
            "src": src.strip(),  # 去掉每行末尾的换行符
            "mt": mt.strip(),
            "ref": ref.strip()
        })
    
    # 发送 POST 请求
    try:
        response = requests.post(url, json=data)
        
        # 处理响应
        if response.status_code == 200:
            comet_scores = response.json().get("comet_da_scores")
            return comet_scores
        else:
            raise Exception(f"请求失败，状态码: {response.status_code}")
    
    except Exception as e:
        print(f"发生错误: {e}")
        return None

# 示例调用
if __name__ == "__main__":
    src_file = './test_files/en.txt'
    mt_file = './test_files/tgt_zh.txt'
    ref_file = './test_files/zh.txt'
    
    # 记录开始时间
    start_time = time.time()

    # 计算 COMET 分数
    comet_scores = compute_comet_score(src_file, mt_file, ref_file)

    # 记录结束时间并计算消耗的时间
    end_time = time.time()
    elapsed_time = end_time - start_time

    if comet_scores:
        print("COMET Scores:", comet_scores)
        print("COMET Average Score:", sum(comet_scores) / len(comet_scores))
    else:
        print("无法获取 COMET 分数")

    # 输出所用时间
    print(f"计算 COMET 分数所用时间: {elapsed_time:.4f} 秒")