import requests

# 皮尔森系数计算请求数据
pearson_data = {
    "manual_scores": [8.0, 8.2, 8.0, 7.8, 7.9],
    "machine_scores": [7.8, 8.1, 7.9, 8.3, 8.0],
    "machine_type": ["bleu", "BERTscore", "NIST", "chrF", "chrFpp"]
}

# COMET-Kiwi 评分计算请求数据（假设已有对应的服务）
comet_kiwi_data = {
    # 根据 comet_kiwi_service 的需求填充数据
}

# 发送皮尔森系数计算 POST 请求
try:
    pearson_response = requests.post("http://127.0.0.1:5001/pearson/calculate_pearson", json=pearson_data)
    if pearson_response.status_code == 200:
        pearson_results = pearson_response.json()
        for result in pearson_results:
            print(f"机器类型: {result.get('machine_type')}")
            print(f"皮尔森系数: {result.get('pearson_coefficient')}")
            print("-" * 20)
    else:
        print(f"皮尔森请求失败，状态码: {pearson_response.status_code}，错误信息: {pearson_response.text}")
except requests.RequestException as e:
    print(f"发送皮尔森请求时出现异常: {e}")