import requests
import json

# 定义服务的 URL
BASE_URL = "http://127.0.0.1:5001/hlerpor/calculate"

# 定义参考文本和候选文本
reference_text = "As the third solar term in the 24 solar terms, Awakening of Insects alludes to the fact that animals sleeping in winter are awakened by spring thunder and that the earth begins to come back to life."
candidate_text = "As the third of the 24 seasons, the Spring Festival means that the animals that have been hibernating are awakened by the spring thunder and the return of the spring."

# 构建请求数据
data = {
    "reference": reference_text,
    "candidate": candidate_text
}

# 发送 POST 请求到 Flask 服务
response = requests.post(BASE_URL, json=data)

# 检查响应状态并输出结果
if response.status_code == 200:
    result = response.json()
    print("hLERPOR Score:", result.get("hlerpor_score"))
else:
    print(f"Error: {response.status_code} - {response.text}")
