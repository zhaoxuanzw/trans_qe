import requests

# url = "http://127.0.0.1:5001/cherrant/"
url = "http://47.120.35.144:45001/cherrant/"


# http://192.168.80.102:20992/cherrant/
path = [
    {
        "original_path": "/home/master/xhj/Trans_QE/error_correct/test_data/ori.txt"
    },
    {
        "translation_path": "/home/master/xhj/Trans_QE/error_correct/test_data/trans.txt"
    },
    {
        "ref_path": "/home/master/xhj/Trans_QE/error_correct/test_data/ref.txt"
    }
]


response = requests.post(url, json=path)

try:
    json_response = response.json()
    print(json_response)
except requests.exceptions.JSONDecodeError as e:
    print("JSONDecodeError:", e)