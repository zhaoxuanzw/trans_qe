import requests

# 定义服务的 URL
BASE_URL = "http://127.0.0.1:5001/chrf/calculate"

# 定义参考文本和候选文本
reference_text = "这是一个参考句子。"
hypothesis_text = "这是一个假设句子。"

# 构建请求数据
data = {
    "reference_text": reference_text,
    "hypothesis_text": hypothesis_text
}

# 发送 POST 请求到 Flask 服务
response = requests.post(BASE_URL, json=data)

# 检查响应状态并输出结果
if response.status_code == 200:
    result = response.json()
    print("chrF Score:", result.get("chrF_score"))
else:
    print(f"Error: {response.status_code} - {response.text}")
