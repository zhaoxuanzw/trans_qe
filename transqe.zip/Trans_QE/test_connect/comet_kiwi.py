import requests
import json

def compute_comet_kiwi(src_file_path, mt_file_path):
    # 读取文件并将每行内容作为列表
    try:
        with open(src_file_path, "r", encoding="utf-8") as src_file:
            src_lines = src_file.readlines()

        with open(mt_file_path, "r", encoding="utf-8") as mt_file:
            mt_lines = mt_file.readlines()

    except FileNotFoundError as e:
        print(f"File not found: {e}")
        return
    except Exception as e:
        print(f"An error occurred: {e}")
        return

    # 检查两文件行数是否匹配
    if len(src_lines) != len(mt_lines):
        print("Error: src.txt and mt.txt must have the same number of lines.")
        return

    # 构建数据列表
    data = [{"src": src.strip(), "mt": mt.strip()} for src, mt in zip(src_lines, mt_lines)]
    print(data)
    # 后端接口 URL
    url = "http://127.0.0.1:5001/comet_kiwi/compute_comet_kiwi"

    # 发送请求
    response = requests.post(url, json=data)

    # 打印响应状态码和响应内容
    print(f"Status Code: {response.status_code}")
    print(f"Response Content: {response.text}")

    # 尝试解析 JSON 响应
    try:
        json_response = response.json()
        # print(json_response)
        scores = json_response['comet_kiwi_scores']
        print('comet_kiwi_scores:', scores)
        print('comet_kiwi_average_score:', sum(scores)/len(scores))
    except requests.exceptions.JSONDecodeError as e:
        print("JSONDecodeError:", e)

# 使用示例
compute_comet_kiwi("./test_files/src.txt", "./test_files/mt.txt")
