import requests

# 读取文件内容的函数
def read_file(file_path):
    """读取文件并返回每一行内容"""
    with open(file_path, 'r', encoding='utf-8') as file:
        return file.readlines()

# 请求 BLEURT 服务的函数
# 请求 BLEURT 服务的函数
def request_bleurt_scores(ref_file, mt_file, url="http://127.0.0.1:5001/bleurt/compute_bleurt"):
    """
    发送请求到 BLEURT 服务计算翻译质量分数
    :param ref_file: 参考句子的文件路径
    :param mt_file: 机器翻译句子的文件路径
    :param url: 后端服务的 URL
    :return: BLEURT 分数列表，如果请求失败则返回 None
    """
    # 读取参考句子和机器翻译句子文件
    ref_sentences = read_file(ref_file)
    mt_sentences = read_file(mt_file)

    # 检查文件是否有相同数量的句子
    if len(ref_sentences) != len(mt_sentences):
        print("Error: The number of sentences in ref.txt and mt.txt must be the same.")
        return None

    # 准备要发送的数据（字典格式）
    data = {
        "data": [
            {"ref": ref.strip(), "mt": mt.strip()}
            for ref, mt in zip(ref_sentences, mt_sentences)
        ]
    }

    # 确认数据格式正确
    print("Data to be sent:", data)

    # 发送 POST 请求并获取响应
    try:
        response = requests.post(url, json=data)
        response.raise_for_status()  # 如果响应状态码不是 200，将抛出异常

        # 尝试解析 JSON 响应
        json_response = response.json()
        return json_response.get("bleurt_scores", None)
    except requests.exceptions.RequestException as e:
        print(f"Request failed: {e}")
        return None
    except requests.exceptions.JSONDecodeError as e:
        print(f"Failed to decode JSON response: {e}")
        return None

# 使用示例
ref_file = "test_files/ref1.txt"
mt_file = "test_files/mt1.txt"
bleurt_scores = request_bleurt_scores(ref_file, mt_file)

if bleurt_scores is not None:
    print("BLEURT Scores:", bleurt_scores)
    print("BLEURT Average Score:", sum(bleurt_scores)/len(bleurt_scores))
else:
    print("Failed to get BLEURT scores.")
