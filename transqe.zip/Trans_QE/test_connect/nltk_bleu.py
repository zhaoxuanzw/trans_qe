import requests
import json

# 定义服务的 URL
BASE_URL = "http://127.0.0.1:5001/nltk_bleu/calculate"

# 定义参考文本和候选文本
reference_text = "今天的天气非常晴朗，适合外出散步。"
candidate_text = "今天天气很好，适合出去走走。"

# 构建请求数据
data = {
    "reference": reference_text,
    "candidate": candidate_text
}

# 发送 POST 请求到 Flask 服务
response = requests.post(BASE_URL, json=data)

# 检查响应状态并输出结果
if response.status_code == 200:
    result = response.json()
    print("BLEU Score:", result.get("bleu_score"))
else:
    print(f"Error: {response.status_code} - {response.text}")
