import requests
import json

# 要发送的 JSON 数据
data = {
    "data": [
        {
            "ori_text": "合同中未提及的事项如何处理？",
            "id": "12"
        },
        {
            "ori_text": "投资需要谨慎并做出明智的决定。",
            "id": "5"
        },
        {
            "ori_text": "台风即将登陆沿海地区，请做好防护措施。",
            "id": None
        }
    ],
    "lang_dir": "zh2en"
}

data = {
    "data": [
        {
            "ori_text": "Example source sentence",
            "id": "12"
        }
    ],
    "lang_dir": "en2el"
}

# Flask 后端的地址
url = 'http://47.120.35.144:45001/data_enhance/translation'
# url = 'http://127.0.0.1:5001/data_enhance/translation'

# 发送 POST 请求
response = requests.post(url, json=data)

# 检查请求是否成功
if response.status_code == 200:
    # 如果成功，打印返回的数据
    print('Response:', response.json())
else:
    # 如果请求失败，打印错误信息
    print('Error:', response.status_code)



# import requests
# import json
# import time

# # 要发送的 JSON 数据
# data = {
#     "data": [
#         {
#             "ori_text": "合同中未提及的事项如何处理？",
#             "id": "12"
#         },
#         {
#             "ori_text": "投资需要谨慎并做出明智的决定。",
#             "id": "5"
#         },
#         {
#             "ori_text": "台风即将登陆沿海地区，请做好防护措施。",
#             "id": None
#         }
#     ],
#     "lang_dir": "zh2en"
# }

# # Flask 后端的地址
# url = 'http://127.0.0.1:5001/data_enhance/translation'

# # 记录总时间
# start_time = time.time()  # 获取开始时间

# # 进行 100 次请求并记录每次请求的时间
# for i in range(100):
#     request_start_time = time.time()  # 每次请求的开始时间
#     try:
#         response = requests.post(url, json=data)  # 发送 POST 请求
#         if response.status_code == 200:
#             # 如果成功，可以选择打印返回的数据（这里暂时不打印）
#             pass
#         else:
#             print(f"Request {i + 1} failed with status code: {response.status_code}")
#     except Exception as e:
#         print(f"Request {i + 1} failed with error: {e}")
    
#     request_end_time = time.time()  # 每次请求的结束时间
#     request_duration = request_end_time - request_start_time  # 单次请求的耗时
#     print(f"Request {i + 1} took {request_duration:.4f} seconds")

# # 计算总的请求时间
# end_time = time.time()  # 获取结束时间
# total_duration = end_time - start_time  # 总耗时

# # 输出总的时间
# print(f"\nTotal time for 100 requests: {total_duration:.4f} seconds")
