# import requests
# import json

# url = "http://127.0.0.1:5000/bert_score/compute_bert_score"
# headers = {"Content-Type": "application/json"}

# # 请求数据
# data = {
#     "model_type": "roberta-large",
#     "refs": ["This is a test sentence.", "Hello world."],
#     "cands": ["This is a test.", "Hello world!"]
# }

# # 发送 POST 请求
# response = requests.post(url, headers=headers, data=json.dumps(data))

# # 输出响应
# print(response.json())

# data = {
#     "model_type": "bert-base-chinese",
#     "refs": ["这是一个测试句子。", "你好，世界！"],
#     "cands": ["这是一个测试。", "你好，世界！"]
# }

# # 发送 POST 请求
# response = requests.post(url, headers=headers, data=json.dumps(data))

# # 输出响应
# print(response.json())

# # 请求数据
# data = {
#     "model_type": "bert-base-multilingual-cased",
#     "refs": ["This is a test sentence.", "Hello world."],
#     "cands": ["This is a test.", "Hello world!"]
# }

# # 发送 POST 请求
# response = requests.post(url, headers=headers, data=json.dumps(data))

# # 输出响应
# print(response.json())


import requests
import json

def load_txt(file_path):
    """读取txt文件并返回其内容"""
    with open(file_path, "r", encoding="utf-8") as file:
        return [line.strip() for line in file.readlines()]

def request_bert_score(ref_file, mt_file, lang):
    """
    发送请求到Flask接口，计算BERT评分
    
    :param ref_file: reference 文件路径
    :param mt_file: machine translation 文件路径
    :param lang: 语言类型, 可选值为 'zh', 'en', 'other'
    :return: 返回的响应内容
    """
    url = "http://127.0.0.1:5001/bert_score/compute_bert_score"
    headers = {"Content-Type": "application/json"}

    # 读取ref.txt和mt.txt文件内容
    refs = load_txt(ref_file)
    cands = load_txt(mt_file)

    # 根据语言类型选择相应的模型
    if lang == 'zh':
        model_type = 'bert-base-chinese'
    elif lang == 'en':
        model_type = 'roberta-large'
    else:
        model_type = 'bert-base-multilingual-cased'

    # 请求数据
    data = {
        "model_type": model_type,
        "refs": refs,
        "cands": cands
    }
    print(data)
    # 发送 POST 请求
    response = requests.post(url, headers=headers, data=json.dumps(data))

    # 返回响应内容
    if response.status_code == 200:
        return response.json()
    else:
        return {"error": "Request failed", "status_code": response.status_code}

# 调用示例
ref_file = "test_files/ref1.txt"  # 请替换为你的文件路径
mt_file = "test_files/mt1.txt"    # 请替换为你的文件路径
lang = "en"  # 语言类型可以是 'zh', 'en', 或 'other'

response = request_bert_score(ref_file, mt_file, lang)
print(response)
print('Average f1:', sum(response['f1'])/len(response['f1']))
print('Average precision:', sum(response['precision'])/len(response['precision']))
print('Average recall:', sum(response['recall'])/len(response['recall']))