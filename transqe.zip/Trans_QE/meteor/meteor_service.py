# from pymeteor import meteor
import nltk
from nltk.translate import meteor_score
from nltk.tokenize import word_tokenize


# 下载必要的 nltk 数据
nltk.download('wordnet')
nltk.download('punkt')


def calculate_meteor(reference_text, hypothesis_text):
    """
    计算参考文本和假设文本之间的 METEOR 分数。
    :param reference_text: 参考文本
    :param hypothesis_text: 假设文本
    :return: METEOR 分数
    """
    # 分词
    reference_tokens = word_tokenize(reference_text.lower())
    hypothesis_tokens = word_tokenize(hypothesis_text.lower())
    # 计算 METEOR 分数
    score = meteor_score.single_meteor_score(reference_tokens, hypothesis_tokens)
    return score