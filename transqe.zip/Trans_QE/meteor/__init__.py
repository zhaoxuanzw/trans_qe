from flask import Blueprint, request, jsonify
from.meteor_service import calculate_meteor

# 创建 Blueprint 对象，URL 前缀为 /meteor
meteor_blueprint = Blueprint('meteor', __name__, url_prefix='/meteor')


@meteor_blueprint.route('/calculate', methods=['POST'])
def calculate_meteor_api():
    data = request.get_json()
    reference_text = data.get('reference_text')
    hypothesis_text = data.get('hypothesis_text')
    if not reference_text or not hypothesis_text:
        return jsonify({"error": "Both reference_text and hypothesis_text are required."}), 400
    meteor_score = calculate_meteor(reference_text, hypothesis_text)
    return jsonify({"meteor_score": meteor_score})