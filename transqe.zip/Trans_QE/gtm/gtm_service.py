import nltk
from nltk.tokenize import word_tokenize


# 下载必要的 nltk 数据
nltk.download('punkt')
nltk.download('punkt_tab')

def calculate_gtm(reference_text, hypothesis_text):
    """
    计算参考文本和假设文本之间的 GTM 分数。
    :param reference_text: 参考文本
    :param hypothesis_text: 假设文本
    :return: GTM 分数
    """
    # 分词
    reference_tokens = word_tokenize(reference_text.lower())
    hypothesis_tokens = word_tokenize(hypothesis_text.lower())

    # 以下是 GTM 分数的计算逻辑，这里假设 GTM 分数是基于词重叠率计算，你可以根据实际 GTM 算法修改
    common_tokens = set(reference_tokens) & set(hypothesis_tokens)
    gtm_score = len(common_tokens) / len(hypothesis_tokens) if hypothesis_tokens else 0
    return gtm_score