from flask import Blueprint, request, jsonify
from.gtm_service import calculate_gtm

# 创建 Blueprint 对象，URL 前缀为 /gtm
gtm_blueprint = Blueprint('gtm', __name__, url_prefix='/gtm')


@gtm_blueprint.route('/calculate', methods=['POST'])
def calculate_gtm_api():
    data = request.get_json()
    reference_text = data.get('reference_text')
    hypothesis_text = data.get('hypothesis_text')
    if not reference_text or not hypothesis_text:
        return jsonify({"error": "Both reference_text and hypothesis_text are required."}), 400
    gtm_score = calculate_gtm(reference_text, hypothesis_text)
    return jsonify({"gtm_score": gtm_score})