from flask import Flask, request, jsonify
import os
import json
import shutil
import subprocess
import urllib.request

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'temp'

# 创建上传文件夹，如果存在则先删除再创建
if os.path.exists(app.config['UPLOAD_FOLDER']):
    shutil.rmtree(app.config['UPLOAD_FOLDER'])
os.makedirs(app.config['UPLOAD_FOLDER'])

def remove_spaces(text):
    return text.replace(" ", "")

def handle_txt_file(address):
    if not address:
        return None
    elif os.path.exists(address):
        # 本地文件
        return address
    elif address.startswith("http://") or address.startswith("https://"):
        # 网络文件
        local_filename = address.split('/')[-1]
        local_path = os.path.join(app.config['UPLOAD_FOLDER'], local_filename)
        urllib.request.urlretrieve(address, local_path)
        return local_path
    else:
        return None 

def parse_correction_file(file_path, original_path):
    corrections = []
    current_sentence = None
    current_translation = None
    current_errors = []

    # 读取 original_path 文件内容
    with open(original_path, 'r') as original_file:
        original_lines = original_file.readlines()

    with open(file_path, 'r') as file:
        lines = file.readlines()
        original_index = 0  # original_path 对应的行索引
        for line in lines:
            line = line.strip()
            if not line:
                # 空行表示一组句子结束
                if current_sentence and current_translation is not None:
                    corrections.append({
                        "translation": remove_spaces(current_sentence),
                        "ref": remove_spaces(current_translation),
                        "errors": current_errors,
                        "original": original_lines[original_index].strip()  # 添加 original 内容
                    })
                    original_index += 1  # 对应下一行 original
                # 重置当前组的变量
                current_sentence = None
                current_translation = None
                current_errors = []
            elif line.startswith('S '):
                current_sentence = line[2:].strip()
            elif line.startswith('T0 '):
                current_translation = line.split(' ', 1)[1].strip()
                current_errors = None  # 表示没有错误
            elif line.startswith('T0-A0'):
                current_translation = line.split(' ', 1)[1].strip()
                current_errors = []
            elif line.startswith('A '):
                if current_errors is not None:
                    parts = line.split('|||')
                    start = int(parts[0].split()[1])
                    end = int(parts[0].split()[2])
                    error_type = parts[1]
                    correction = parts[2]
                    current_errors.append({
                        "start": start,
                        "end": end,
                        "error_type": error_type,
                        "correction": correction
                    })

    # 添加最后一组句子
    if current_sentence and current_translation is not None:
        corrections.append({
            "translation": remove_spaces(current_sentence),
            "ref": remove_spaces(current_translation),
            "errors": current_errors,
            "original": original_lines[original_index].strip()  # 添加 original 内容
        })

    return corrections

def replace_ref(hyp_file, ref_file, output_file):
    # 读取hyp.txt和ref.txt文件
    with open(hyp_file, 'r', encoding='utf-8') as hf:
        hyp_lines = hf.read().split('\n\n')
        
    with open(ref_file, 'r', encoding='utf-8') as rf:
        ref_lines = rf.readlines()
    
    processed_blocks = []
    
    for i, block in enumerate(hyp_lines):
        lines = block.strip().split('\n')
        if len(lines) > 1 and lines[1] == 'T0 没有错误':
            lines[1] = f'T0 {ref_lines[i].strip()}'
        processed_blocks.append('\n'.join(lines))
    
    # 将处理后的内容写回新的文件
    with open(output_file, 'w', encoding='utf-8') as of:
        of.write('\n\n'.join(processed_blocks))

def process_txt_file(input_file_path):
    with open(input_file_path, 'r', encoding='utf-8') as file:
        lines = file.readlines()

    processed_lines = []
    i = 0

    while i < len(lines):
        line = lines[i].rstrip()  # 去除行尾的空白符，包括换行符
        # 检查当前行是否以数字开头
        if line and line[0].isdigit():
            # 检查下一行是否存在且是否以数字开头
            if i + 1 < len(lines) and not lines[i + 1].lstrip().startswith(tuple("0123456789")):
                # 将当前行和下一行合并，并添加到处理后的列表
                line += " " + lines[i + 1].strip()
                i += 1  # 跳过下一行，因为已经合并
        # 将合并后的行或原始行添加到处理后的列表
        processed_lines.append(line)
        i += 1

    # 将修正后的内容写回源文件
    with open(input_file_path, 'w', encoding='utf-8') as file:
        for line in processed_lines:
            file.write(line + '\n')

@app.route('/cherrant', methods=['POST'])
def check_error():
    data = request.get_json()
    # 创建上传文件夹，如果存在则先删除再创建
    #确保每次执行时都是新的temp文件夹，不会有残留文件干扰
    if os.path.exists(app.config['UPLOAD_FOLDER']):
        shutil.rmtree(app.config['UPLOAD_FOLDER'])
    os.makedirs(app.config['UPLOAD_FOLDER'])
    
    if not data:
        return jsonify({"error": "No JSON data received"}), 400

    original_path = None
    translation_path = None
    ref_path = None

    for item in data:
        if 'original_path' in item:
            original_path = handle_txt_file(item['original_path'])
        elif 'translation_path' in item:
            translation_path = handle_txt_file(item['translation_path'])
        elif 'ref_path' in item:
            ref_path = handle_txt_file(item['ref_path'])
    print(original_path,translation_path,ref_path)
    # return jsonify({"message": "Files processed successfully"}), 200
    if not original_path or not translation_path:
        return jsonify({"error": "Original path or translation path is missing"}), 400

    
    try:
        with open(original_path, 'r') as file:
            original_lines = file.readlines()

        with open(translation_path, 'r') as file:
            translation_lines = file.readlines()
        #在无参考译文的情况下，如果原文和译文行数不等则报错，相等则返回json即可
        if not ref_path:
            if len(original_lines) != len(translation_lines):
                return jsonify({"error": "Original and translation files have different number of lines"}), 400

            result_json = []
            for orig, trans in zip(original_lines, translation_lines):
                result_json.append({
                    "original": orig.strip(),
                    "translation": trans.strip(),
                    "ref": None,
                    "errors": None
                })
            return jsonify(result_json)
            result_json_path = os.path.join(app.config['UPLOAD_FOLDER'], 'result.json')
            with open(result_json_path, 'w', encoding='utf-8') as json_file:
                json.dump(result_json, json_file, ensure_ascii=False, indent=4)

            return jsonify({"message": "Processing completed","result_path": result_json_path}), 200

        with open(ref_path, 'r') as file:
            ref_lines = file.readlines()

        #有参考译文的情况下，如果三个文件行数不同则报错
        if not (len(original_lines) == len(translation_lines) == len(ref_lines)):
            return jsonify({"error": "Original,translation and ref files have different number of lines"}), 400

        para_file_path = os.path.join(app.config['UPLOAD_FOLDER'], 'para.txt')
        hyp_file_path = os.path.join(app.config['UPLOAD_FOLDER'], 'hyp.txt')


        # 生成平行格式文件
        paste_command = f"paste {ref_path} {translation_path} | awk '{{print NR\"\t\"$0}}' > {para_file_path}"
        print("文件路径为")
        print(para_file_path)
        process_txt_file(para_file_path)
        subprocess.run(paste_command, shell=True, check=True)

        # 调用 parallel_to_m2.py 进行纠错
        parallel_to_m2_command = f"python parallel_to_m2.py -f {para_file_path} -o {hyp_file_path} -g char"
        subprocess.run(parallel_to_m2_command, shell=True, check=True)

        # 源程序得到的结果文件中，如果某句没有错误，那么ref字段为“没有错误”，需要找到原ref句子进行替换
        output_file = os.path.join(app.config['UPLOAD_FOLDER'], 'hyp_replaced.txt')
        replace_ref(hyp_file_path,ref_path,output_file)
        # 读取纠错后的结果并解析
        corrections = parse_correction_file(output_file,original_path)
        return jsonify(corrections), 200
        # # 下面代表另外一种返回格式，可以将json地址返回
        # result_json_path = os.path.join(app.config['UPLOAD_FOLDER'], 'result.json')
        # with open(result_json_path, 'w', encoding='utf-8') as json_file:
        #     json.dump(corrections, json_file, ensure_ascii=False, indent=4)
        
        # return jsonify({"message": "Processing completed","result_path": result_json_path}), 200

    except FileNotFoundError as e:
        return jsonify({"error": f"File not found: {e}"}), 400
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5002)
