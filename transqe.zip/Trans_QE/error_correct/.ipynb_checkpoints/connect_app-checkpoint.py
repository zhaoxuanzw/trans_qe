import requests

url = "http://127.0.0.1:5002/cherrant"

path = [
    {
        "original_path": "http://47.120.35.144:1818/prod-api/profile/upload/2024/08/12/ori_20240812172955A006.txt"
    },
    {
        "translation_path": "http://47.120.35.144:1818/prod-api/profile/upload/2024/08/12/trans_20240812173117A008.txt"
    },
    {
        "ref_path": None
    }
]


response = requests.post(url, json=path)

try:
    json_response = response.json()
    print(json_response)
except requests.exceptions.JSONDecodeError as e:
    print("JSONDecodeError:", e)