import json
def parse_correction_file(file_path, original_path):
    corrections = []
    current_sentence = None
    current_translation = None
    current_errors = []

    # 读取 original_path 文件内容
    with open(original_path, 'r') as original_file:
        original_lines = original_file.readlines()

    with open(file_path, 'r') as file:
        lines = file.readlines()
        original_index = 0  # original_path 对应的行索引
        for line in lines:
            line = line.strip()
            if not line:
                # 空行表示一组句子结束
                if current_sentence and current_translation is not None:
                    corrections.append({
                        "translation": current_sentence,
                        "ref": current_translation,
                        "errors": current_errors,
                        "original": original_lines[original_index].strip()  # 添加 original 内容
                    })
                    original_index += 1  # 对应下一行 original
                # 重置当前组的变量
                current_sentence = None
                current_translation = None
                current_errors = []
            elif line.startswith('S '):
                current_sentence = line[2:].strip()
            elif line.startswith('T0 '):
                current_translation = line.split(' ', 1)[1].strip()
                current_errors = None  # 表示没有错误
            elif line.startswith('T0-A0'):
                current_translation = line.split(' ', 1)[1].strip()
                current_errors = []
            elif line.startswith('A '):
                if current_errors is not None:
                    parts = line.split('|||')
                    start = int(parts[0].split()[1])
                    end = int(parts[0].split()[2])
                    error_type = parts[1]
                    correction = parts[2]
                    current_errors.append({
                        "start": start,
                        "end": end,
                        "error_type": error_type,
                        "correction": correction
                    })

    # 添加最后一组句子
    if current_sentence and current_translation is not None:
        corrections.append({
            "translation": current_sentence,
            "ref": current_translation,
            "errors": current_errors,
            "original": original_lines[original_index].strip()  # 添加 original 内容
        })

    return corrections


def main():
    file_path = "./temp/hyp_replaced.txt"
    original_path = "test_data/ori.txt"
    res = parse_correction_file(file_path,original_path)
    with open('data.json', 'w', encoding='utf-8') as json_file:
        json.dump(res, json_file, ensure_ascii=False, indent=4)
    # print(res)

if __name__ == "__main__":
    main()