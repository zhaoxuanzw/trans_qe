import os
import json
import shutil
import subprocess
import urllib.request
from flask import request, jsonify
import ahocorasick

UPLOAD_FOLDER = os.path.abspath('temp')

# 创建上传文件夹
def initialize_upload_folder():
    if os.path.exists(UPLOAD_FOLDER):
        shutil.rmtree(UPLOAD_FOLDER)
    os.makedirs(UPLOAD_FOLDER)

def remove_spaces(text):
    return text.replace(" ", "")

def handle_txt_file(address):
    if not address:
        return None
    elif os.path.exists(address):
        return address
    elif address.startswith("http://") or address.startswith("https://"):
        local_filename = address.split('/')[-1]
        local_path = os.path.join(UPLOAD_FOLDER, local_filename)
        urllib.request.urlretrieve(address, local_path)
        return local_path
    else:
        return None 

def parse_correction_file(file_path, original_path):
    corrections = []
    current_sentence = None
    current_translation = None
    current_errors = []

    # 读取 original_path 文件内容
    with open(original_path, 'r') as original_file:
        original_lines = original_file.readlines()

    with open(file_path, 'r') as file:
        lines = file.readlines()
        original_index = 0  # original_path 对应的行索引
        for line in lines:
            line = line.strip()
            if not line:
                # 空行表示一组句子结束
                if current_sentence and current_translation is not None:
                    corrections.append({
                        "translation": remove_spaces(current_sentence),
                        "ref": remove_spaces(current_translation),
                        "errors": current_errors,
                        "original": original_lines[original_index].strip()  # 添加 original 内容
                    })
                    original_index += 1  # 对应下一行 original
                # 重置当前组的变量
                current_sentence = None
                current_translation = None
                current_errors = []
            elif line.startswith('S '):
                current_sentence = line[2:].strip()
            elif line.startswith('T0 '):
                current_translation = line.split(' ', 1)[1].strip()
                current_errors = None  # 表示没有错误
            elif line.startswith('T0-A0'):
                current_translation = line.split(' ', 1)[1].strip()
                current_errors = []
            elif line.startswith('A '):
                if current_errors is not None:
                    parts = line.split('|||')
                    start = int(parts[0].split()[1])
                    end = int(parts[0].split()[2])
                    error_type = parts[1]
                    correction = parts[2]
                    current_errors.append({
                        "start": start,
                        "end": end,
                        "error_type": error_type,
                        "correction": correction
                    })

    # 添加最后一组句子
    if current_sentence and current_translation is not None:
        corrections.append({
            "translation": remove_spaces(current_sentence),
            "ref": remove_spaces(current_translation),
            "errors": current_errors,
            "original": original_lines[original_index].strip()  # 添加 original 内容
        })

    return corrections

def check_terms_in_translation(corrections, terms_file_path):
    # 创建 Aho-Corasick 自动机
    automaton = ahocorasick.Automaton()

    # 读取术语库并构建 Aho-Corasick 自动机
    with open(terms_file_path, 'r', encoding='utf-8') as terms_file:
        for index, term in enumerate(terms_file.readlines()):
            term = term.strip()
            automaton.add_word(term, (index, term))  # 使用术语的索引和值作为自动机的节点

    # 构建自动机
    automaton.make_automaton()

    # 遍历 corrections 数据
    for correction in corrections:
        ref_sentence = correction['ref']  # 获取 ref 中的句子
        trans_sentence = correction['translation']  # 获取 translation 中的句子
        ref_errors = []

        # 在 ref 句子中使用 Aho-Corasick 查找术语
        for end_pos, (index, term) in automaton.iter(ref_sentence):
            start_pos = end_pos - len(term) + 1  # 计算术语在 ref 中的开始位置
            if term not in trans_sentence:  # 如果 trans 句子中没有这个术语
                # 术语错误，添加到 errors 中
                ref_errors.append({
                    "start": start_pos,
                    "end": end_pos,
                    "error_type": "T",
                    "correction": f"缺少术语: {term}"
                })

        # 如果找到了术语错误，添加到 correction['errors']
        if ref_errors:
            correction['errors'].extend(ref_errors)

    return corrections

def check_passive_voice(corrections):
    """
    检查语态错误，识别被动语态。
    如果 ref_sentence 中包含“被”，但 trans_sentence 中没有“被”，则报告语态错误。
    """
    for correction in corrections:
        ref_sentence = correction['ref']  # 获取 ref 中的句子
        trans_sentence = correction['translation']  # 获取 translation 中的句子
        voice_errors = []

        # 检查 ref_sentence 是否包含“被”
        if '被' in ref_sentence and '被' not in trans_sentence:
            voice_errors.append({
                "error_type": "V",
                "correction": "缺少被动语态"
            })

        # 如果找到了语态错误，添加到 correction['errors']
        if voice_errors:
            correction['errors'].extend(voice_errors)

    return corrections

def replace_ref(hyp_file, ref_file, output_file):
    # 读取hyp.txt和ref.txt文件
    with open(hyp_file, 'r', encoding='utf-8') as hf:
        hyp_lines = hf.read().split('\n\n')
        
    with open(ref_file, 'r', encoding='utf-8') as rf:
        ref_lines = rf.readlines()
    
    processed_blocks = []
    
    for i, block in enumerate(hyp_lines):
        lines = block.strip().split('\n')
        if len(lines) > 1 and lines[1] == 'T0 没有错误':
            lines[1] = f'T0 {ref_lines[i].strip()}'
        processed_blocks.append('\n'.join(lines))
    
    # 将处理后的内容写回新的文件
    with open(output_file, 'w', encoding='utf-8') as of:
        of.write('\n\n'.join(processed_blocks))

def process_txt_file(input_file_path):
    with open(input_file_path, 'r', encoding='utf-8') as file:
        lines = file.readlines()

    processed_lines = []
    i = 0

    while i < len(lines):
        line = lines[i].rstrip()  # 去除行尾的空白符，包括换行符
        # 检查当前行是否以数字开头
        if line and line[0].isdigit():
            # 检查下一行是否存在且是否以数字开头
            if i + 1 < len(lines) and not lines[i + 1].lstrip().startswith(tuple("0123456789")):
                # 将当前行和下一行合并，并添加到处理后的列表
                line += "\t" + lines[i + 1].strip()
                i += 1  # 跳过下一行，因为已经合并
        # 将合并后的行或原始行添加到处理后的列表
        processed_lines.append(line)
        i += 1

    # 将修正后的内容写回源文件
    with open(input_file_path, 'w', encoding='utf-8') as file:
        for line in processed_lines:
            file.write(line + '\n')

def remove_empty_lines(file_path):
    """
    读取文本文件，去除其中完全为空或仅包含空格的行，并将处理后的内容写回原文件。
    """
    if file_path == None:
        return
    cleaned_lines = []
    with open(file_path, 'r', encoding='utf-8') as file:
        for line in file:
            cleaned_line = line.strip()  # 去除行首尾的空白字符（包括空格、tab、换行符等）
            if cleaned_line:  # 如果去除空白后的行不为空，保留该行
                cleaned_lines.append(line)  # 保留原始行内容，不去掉换行符
    
    # 将处理后的内容写回原文件
    with open(file_path, 'w', encoding='utf-8') as file:
        for line in cleaned_lines:
            file.write(line)  # 逐行写回原文件


def check_error(request):
    data = request.get_json()
    initialize_upload_folder()
    
    if not data:
        return jsonify({"error": "No JSON data received"}), 400

    original_path = None
    translation_path = None
    ref_path = None
    # 如果是网络文件，先读取网络文件到本地
    for item in data:
        if 'original_path' in item:
            original_path = handle_txt_file(item['original_path'])
        elif 'translation_path' in item:
            translation_path = handle_txt_file(item['translation_path'])
        elif 'ref_path' in item:
            ref_path = handle_txt_file(item['ref_path'])
    print(original_path, translation_path, ref_path)
    
    # 没有源文件和翻译文件，直接报错并返回
    if not original_path or not translation_path:
        return jsonify({"error": "Original path or translation path is missing"}), 400

    # 文件中可能存在多行对应的空行，需要进行处理
    remove_empty_lines(original_path)
    remove_empty_lines(translation_path)
    remove_empty_lines(ref_path)

    try:
        with open(original_path, 'r') as file:
            original_lines = file.readlines()

        with open(translation_path, 'r') as file:
            translation_lines = file.readlines()
        
        # 没有参考文件，代表返回源文件和翻译文件的处理分支，不经过多余处理，直接返回json即可
        if not ref_path:
            if len(original_lines) != len(translation_lines):
                return jsonify({"error": "Original and translation files have different number of lines"}), 400

            result_json = []
            for orig, trans in zip(original_lines, translation_lines):
                result_json.append({
                    "original": orig.strip(),
                    "translation": trans.strip(),
                    "ref": None,
                    "errors": None
                })
            return jsonify(result_json)

        with open(ref_path, 'r') as file:
            ref_lines = file.readlines()

        # 三个文件行数不相同，后续处理会出现错误，直接检测进行报错返回
        if not (len(original_lines) == len(translation_lines) == len(ref_lines)):
            return jsonify({"error": "Original, translation, and ref files have different number of lines"}), 400

        para_file_path = os.path.join(UPLOAD_FOLDER, 'para.txt')
        hyp_file_path = os.path.join(UPLOAD_FOLDER, 'hyp.txt')
        # 将参考译文和译文处理为 一行 id \t ref \t trans 的格式
        paste_command = f"paste {translation_path} {ref_path} | awk '{{print NR\"\t\"$0}}' > {para_file_path}"
        
        subprocess.run(paste_command, shell=True, check=True)
        process_txt_file(para_file_path)

        current_dir = os.path.dirname(os.path.abspath(__file__))
        parallel_script_path = os.path.join(current_dir, 'parallel_to_m2.py')

        # char级别纠错并输出对比文本
        parallel_to_m2_command = f"python {parallel_script_path} -f {para_file_path} -o {hyp_file_path} -g char"
        subprocess.run(parallel_to_m2_command, shell=True, check=True)

        output_file = os.path.join(UPLOAD_FOLDER, 'hyp_replaced.txt')
        replace_ref(hyp_file_path, ref_path, output_file)

        # 调用解析函数，解析错误类型，返回最后的json错误格式
        corrections = parse_correction_file(output_file, original_path)
        corrections = check_terms_in_translation(corrections,"error_correct/test_data/random_chinese_terms.txt")
        corrections = check_passive_voice(corrections)
        return jsonify(corrections), 200

    except FileNotFoundError as e:
        return jsonify({"error": f"File not found: {e}"}), 400
    except Exception as e:
        return jsonify({"error": str(e)}), 500
