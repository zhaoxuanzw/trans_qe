import requests

url = "http://127.0.0.1:5002/cherrant"

path = [
    {
        "original_path": "/home/dny_demo/jupyterlab/ChERRANT/test_data/ori.txt"
    },
    {
        "translation_path": "/home/dny_demo/jupyterlab/ChERRANT/test_data/trans.txt"
    },
    {
        "ref_path": "/home/dny_demo/jupyterlab/ChERRANT/test_data/ref.txt"
    }
]


response = requests.post(url, json=path)

try:
    json_response = response.json()
    print(json_response)
except requests.exceptions.JSONDecodeError as e:
    print("JSONDecodeError:", e)