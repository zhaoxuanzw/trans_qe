from flask import Blueprint, request, jsonify
from .cherrant_service import check_error  # 导入 ChERRANT 逻辑函数

# 创建 Blueprint 对象，URL 前缀为 /cherrant
cherrant_blueprint = Blueprint('cherrant', __name__, url_prefix='/cherrant')
print("cherrant_blueprint successfully defined.")

@cherrant_blueprint.route('/', methods=['POST'])
def cherrant_api():
    return check_error(request)

__all__ = ['cherrant_blueprint']