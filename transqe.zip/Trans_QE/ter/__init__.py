from flask import Blueprint, request, jsonify
from .ter_service import ter

# 创建 Blueprint 对象，URL 前缀为 /ter
ter_blueprint = Blueprint('ter', __name__, url_prefix='/ter')

@ter_blueprint.route('/calculate', methods=['POST'])
def calculate_ter_api():
    data = request.get_json()
    reference = data.get('reference')
    candidate = data.get('candidate')
    if not reference or not candidate:
        return jsonify({"error": "Both reference and candidate texts are required."}), 400
    # 将参考文本和候选文本按空格分词
    ter_score = ter(reference.split(), candidate.split())
    return jsonify({"ter_score": ter_score})
