from flask import Blueprint, request, jsonify
from .hlerpor_service import calculate_hlerpor

# 创建 Blueprint 对象，URL 前缀为 /hlerpor
hlerpor_blueprint = Blueprint('hlerpor', __name__, url_prefix='/hlerpor')

@hlerpor_blueprint.route('/calculate', methods=['POST'])
def calculate_hlerpor_api():
    data = request.get_json()
    reference = data.get('reference')
    candidate = data.get('candidate')
    if not reference or not candidate:
        return jsonify({"error": "Both reference and candidate texts are required."}), 400
    hlerpor_score = calculate_hlerpor(reference, candidate)
    return jsonify({"hlerpor_score": hlerpor_score})
