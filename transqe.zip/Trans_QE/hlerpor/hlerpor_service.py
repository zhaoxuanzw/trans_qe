import math
import jieba
from typing import List, Tuple

def tokenize(text: str, lang: str = "auto") -> List[str]:
    """
    根据语言对文本进行分词。
    
    参数:
        text (str): 输入文本。
        lang (str): 语言类型，支持 "en" (英文)、"zh" (中文) 或 "auto" (自动检测)。
    
    返回:
        List[str]: 分词后的单词列表。
    """
    if lang == "auto":
        lang = "zh" if "\u4e00" <= text[0] <= "\u9fff" else "en"  # 根据首个字符判断语言
    
    if lang == "zh":
        return list(jieba.cut(text))
    else:
        return text.split()

def calculate_hlerpor(system_translation: str, reference_translation: str, 
                     alpha: float = 9, weight_PR: float = 7, 
                     weight_LP: float = 2, weight_Pos: float = 1, lang: str = "auto") -> float:
    """
    计算 hLEPOR 分数。
    
    参数:
        system_translation (str): 系统翻译的句子。
        reference_translation (str): 参考翻译的句子。
        alpha (float): 调整精确度和召回率权重的参数，默认为 9。
        weight_PR (float): 精确度和召回率调和平均值的权重，默认为 7。
        weight_LP (float): 长度惩罚的权重，默认为 2。
        weight_Pos (float): 位置差异惩罚的权重，默认为 1。
        lang (str): 语言类型，支持 "en"、"zh" 或 "auto"。
    
    返回:
        float: hLEPOR 分数。
    """
    # 分词处理
    system_words = tokenize(system_translation, lang)
    reference_words = tokenize(reference_translation, lang)
    
    # 计算长度惩罚 (LP)
    system_length = len(system_words)
    reference_length = len(reference_words)
    if system_length == 0 or reference_length == 0:
        return 0.0  # 如果任一翻译为空，直接返回 0 分
    
    if system_length > reference_length:
        LP = math.exp(1 - (system_length / reference_length))
    else:
        LP = math.exp(1 - (reference_length / system_length))
    
    # 计算精确度 (P) 和召回率 (R)
    common_words = 0
    reference_matched = [False] * reference_length  # 标记参考翻译中已匹配的单词
    
    for i, word in enumerate(system_words):
        if word in reference_words:
            index = reference_words.index(word)
            if not reference_matched[index]:  # 如果参考翻译中的单词未被匹配
                common_words += 1
                reference_matched[index] = True
    
    P = common_words / system_length
    R = common_words / reference_length
    
    # 计算调和平均值 (H(P, aR))
    if P == 0 and R == 0:
        harmonic_mean_PR = 0.0
    else:
        harmonic_mean_PR = (1 + alpha) * P * R / (R + alpha * P)
    
    # 计算位置差异惩罚 (PosDiffValue)
    pos_diff_sum = 0.0
    for i, word in enumerate(system_words):
        if word in reference_words:
            index = reference_words.index(word)
            pos_diff_sum += abs((i + 1) / system_length - (index + 1) / reference_length)
    
    pos_diff_value = math.exp(-pos_diff_sum / system_length)
    
    # 计算 hLEPOR 分数
    if LP > 0 and pos_diff_value > 0 and harmonic_mean_PR > 0:
        hlepor = (weight_LP + weight_Pos + weight_PR) / (weight_LP / LP + weight_Pos / pos_diff_value + weight_PR / harmonic_mean_PR)
    else:
        hlepor = 0.0
    
    return hlepor