import os
os.environ["CUDA_VISIBLE_DEVICES"] = "3"  # 设置使用显卡1

import ssl
ssl._create_default_https_context = ssl._create_unverified_context

import sys
sys.path.append('/home/dny_demo/jupyterlab/Trans_QE')

from flask import Flask

from comet_qe import comet_qe_blueprint
from comet_kiwi import comet_kiwi_blueprint
from comet_da import comet_da_blueprint
from bleurt import bleurt_blueprint
from data_enhancement import data_enhance_bleuprint
from pearson_correlation import pearson_blueprint
from error_correct import cherrant_blueprint
from sacre_bleu import sacrebleu_blueprint
from nltk_bleu import nltk_bleu_blueprint
from bertscore import bert_score_blueprint
from hlerpor import hlerpor_blueprint
from ter import ter_blueprint
from chrfpp import chrfpp_blueprint
from chrf import chrf_blueprint
from nist import nist_blueprint
from meteor import meteor_blueprint
from gtm import gtm_blueprint

app = Flask(__name__)

# # 注册各服务

# 三个comet 评分，da是有参考的   qe和kiwi是无参考的
app.register_blueprint(comet_qe_blueprint)  # 路由前缀 /comet_qe/compute_comet_qe  
app.register_blueprint(comet_kiwi_blueprint)  # 路由前缀 /comet_kiwi/compute_comet_kiwi
app.register_blueprint(comet_da_blueprint)  # 路由前缀  /comet_da/compute_comet_da

app.register_blueprint(bleurt_blueprint)      # 路由前缀 /bleurt/compute_bleurt
app.register_blueprint(data_enhance_bleuprint)  # 路由前缀 /data_enhance/translation
app.register_blueprint(pearson_blueprint)   # 路由前缀 /pearson/calculate_pearson
app.register_blueprint(cherrant_blueprint)  # 路由前缀 /cherrant/
app.register_blueprint(sacrebleu_blueprint) # 路由前缀 /sacrebleu/calculate  #此接口还有问题
app.register_blueprint(nltk_bleu_blueprint)  # 路由前缀 /nltk_bleu/calculate
app.register_blueprint(bert_score_blueprint) # 路由前缀 /bert_score/compute_bert_score
app.register_blueprint(hlerpor_blueprint)  # 路由前缀  /hlerpor/calculate
app.register_blueprint(ter_blueprint)  # 路由前缀  /ter/calculate
app.register_blueprint(chrfpp_blueprint)  # 路由前缀 /chrfpp/calculate
app.register_blueprint(chrf_blueprint)  # 路由前缀 /chrf/calculate
app.register_blueprint(nist_blueprint)  # 路由前缀 /nist/calculate
app.register_blueprint(meteor_blueprint)  # 路由前缀 /meteor/calculate
app.register_blueprint(gtm_blueprint)  # 路由前缀 /gtm/calculate

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5001)
