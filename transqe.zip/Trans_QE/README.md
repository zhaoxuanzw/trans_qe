
# 部署说明：
所有用到的模型都存在地址`./models/`下面，其中有几个模型需要复制到系统地址下
```bash
cd models
cp -r models--xlm-roberta-large/ ~/.cache/huggingface/hub
cp -r models--microsoft--infoxlm-large/ ~/.cache/huggingface/hub
cp -r  models--roberta-large/ ~/.cache/huggingface/hub
cp -r models--bert-base-chinese/ ~/.cache/huggingface/hub
cp -r models--bert-base-multilingual-cased/ ~/.cache/huggingface/hub
```

# 部署硬件需求
下面这几个服务需要用到显卡：
`comet-da`、`comet-qe`、`comet-kiwi`、`bleurt`和`data_enhance`，这四个服务需要24G显存

注意`comet-qe`、`comet-kiwi`和`bleurt`使用的是相对路径，部署时如出错检查模型相对地址

1. `./comet_kiwi/comet_kiwi_service.py`
2. `./comet_qe/comet_qe_service.py`
3. `./bleurt/bleurt_service.py`
4. `./comet_qe/comet_da_service.py`

注意`bertscore`将三个模型复制到系统地址后，应该可以直接调用，不用更改地址了，如果出错，更改`./bertscore/bert_score_service.py`  19行注释有说明

注意`data_enhance`数据增强部分，是基于训练Llama3训练了一个包含下面5个语向的翻译模型
- 中文-英文       `zh2en`
- 中文-意大利语`zh2it`
- 中文-希腊语`zh2el`
- 英文-意大利语`en2it`
- 英文-希腊语`en2el`

llama模型的地址在`./data_enhancement/data_enhance_service.py`文件中122行


# 模型调用方法
## comet_kiwi
调用脚本`./test_connect/comet_kiwi.py` 
传入两个文件：源语言文件"src.txt" 和目标翻译文件"mt.txt"，输出文件每行的comet_kiwi_score
```
Response Content: {"comet_kiwi_scores":[0.8331686854362488,0.7671147584915161,0.8827177882194519]}
```

## comet_qe
调用脚本`./test_connect/comet_qe.py` 
传入两个文件：源语言文件"src.txt" 和目标翻译文件"mt.txt"，输出文件每行的comet_qe_score

## bleurt
调用脚本`./test_connect/bleurt.py`
传入两个文件：参考译文"ref.txt"和目标翻译文件"mt.txt"，输出每行的bleurt分数
```
BLEURT Scores: [0.9990503191947937, 0.7930179834365845]
```
## bertscore
bertscore 模型使用不同语言时会调用不同的模型，暂时都是直接加载的方式，可以通过调用`./test_connect/bert_score.py`计算，需要修改`./test_connect/bert_score.py`下面的模型路径
```
lang==zh --model = bert-base-chinese
lang==en  --model = roberta-large
lang==other  --model = bert-base-multilingual-cased
```
传入两个文件参考译文"ref.txt"和目标翻译文件"mt.txt"，以及对应的语种—— 中文（zh） 英文（en） 其他语言（other）共3个参数，返回一个列表
```
{'f1': [1.0, 0.9590552449226379], 'precision': [1.0, 0.9527958631515503], 'recall': [1.0, 0.9653973579406738]}
```