import os
os.environ["CUDA_VISIBLE_DEVICES"] = "0"  # 设置使用显卡

from transformers import AutoTokenizer, AutoConfig, AddedToken
import torch
from loguru import logger
import copy
import json
import argparse
from tqdm import tqdm 
import sys
sys.path.append("../../")
from .utils import ModelUtils
from dataclasses import dataclass
from typing import List, Dict, Any
import langid

# 定义 Template 类
@dataclass
class Template:
    template_name: str
    system_format: str
    user_format: str
    assistant_format: str
    system: str
    stop_word: str

# 直接定义 template_dict，并初始化 llama3 模板
template_dict: Dict[str, Template] = {
    'llama3': Template(
        template_name='llama3',
        system_format='<|begin_of_text|><|start_header_id|>system<|end_header_id|>\n\n{content}<|eot_id|>',
        user_format='<|start_header_id|>user<|end_header_id|>\n\n{content}<|eot_id|><|start_header_id|>assistant<|end_header_id|>\n\n',
        assistant_format='{content}<|eot_id|>',
        system=None,
        stop_word='<|eot_id|>'
    )
}

def build_prompt_chatglm3(tokenizer, query, history, system=None):
    history.append({"role": 'user', 'message': query})
    # system
    input_ids = tokenizer.get_prefix_tokens() + \
                [tokenizer.get_command(f"<|system|>")] + \
                tokenizer.encode(system, add_special_tokens=False)
    # convs
    for item in history:
        role, message = item['role'], item['message']
        if role == 'user':
            tokens = [tokenizer.get_command(f"<|user|>")] + \
                     tokenizer.encode(message, add_special_tokens=False) + \
                     [tokenizer.get_command(f"<|assistant|>")]
        else:
            tokens = tokenizer.encode(message, add_special_tokens=False) + [tokenizer.eos_token_id]
        input_ids += tokens

    return input_ids


def build_prompt(tokenizer, template, query, history, system=None):
    template_name = template.template_name
    system_format = template.system_format
    user_format = template.user_format
    assistant_format = template.assistant_format
    system = system if system is not None else template.system

    if template_name == 'chatglm2':
        prompt = tokenizer.build_prompt(query, history)
        input_ids = tokenizer.encode(prompt)
    elif template_name == 'chatglm3':
        input_ids = build_prompt_chatglm3(tokenizer, query, history, system)
    else:
        history.append({"role": 'user', 'message': query})
        input_ids = []

        # setting system information
        if system_format is not None:
            # system信息不为空
            if system is not None:
                system_text = system_format.format(content=system)
                input_ids = tokenizer.encode(system_text, add_special_tokens=False)
        # concat conversation
        for item in history:
            role, message = item['role'], item['message']
            if role == 'user':
                message = user_format.format(content=message, stop_token=tokenizer.eos_token)
            else:
                message = assistant_format.format(content=message, stop_token=tokenizer.eos_token)
            tokens = tokenizer.encode(message, add_special_tokens=False)
            input_ids += tokens
    input_ids = torch.tensor([input_ids], dtype=torch.long)

    return input_ids


def load_tokenizer(model_name_or_path):
    # config = AutoConfig.from_pretrained(model_name_or_path, trust_remote_code=True)
    # 加载tokenzier
    tokenizer = AutoTokenizer.from_pretrained(
        model_name_or_path,
        trust_remote_code=True,
        use_fast=False
        # llama不支持fast
        # use_fast=False if config.model_type == 'llama' else True
    )

    if tokenizer.__class__.__name__ == 'QWenTokenizer':
        tokenizer.pad_token_id = tokenizer.eod_id
        tokenizer.bos_token_id = tokenizer.eod_id
        tokenizer.eos_token_id = tokenizer.eod_id
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    # assert tokenizer.pad_token_id is not None, "pad_token_id should not be None"
    return tokenizer

model = None
tokenizer = None


def load_model():
    global model,tokenizer
    model_name_or_path = '/home/master/xhj/Firefly/merged_model/firefly-llama-8b-pretrain-qlora' #llama
    # template_name = 'llama3'
    # adapter_name_or_path = None
    adapter_name_or_path = '/home/master/xhj/Firefly/output/firefly-llama3-8b-sft-lora'

    template = template_dict['llama3']
    # 是否使用4bit进行推理，能够节省很多显存，但效果可能会有一定的下降
    load_in_4bit = False
    # 生成超参配置
    max_new_tokens = 500
    top_p = 0.9
    temperature = 0.35
    repetition_penalty = 1.0
    # 加载模型
    logger.info(f'Loading model from: {model_name_or_path}')
    logger.info(f'adapter_name_or_path: {adapter_name_or_path}')
    model = ModelUtils.load_model(
        model_name_or_path,
        load_in_4bit=load_in_4bit,
        adapter_name_or_path=adapter_name_or_path
    ).eval()
    tokenizer = load_tokenizer(model_name_or_path if adapter_name_or_path is None else adapter_name_or_path)


def translate(text, lang_dir):
    global model,tokenizer
    template = template_dict['llama3']
    # 是否使用4bit进行推理，能够节省很多显存，但效果可能会有一定的下降
    load_in_4bit = False
    # 生成超参配置
    max_new_tokens = 500
    top_p = 0.9
    temperature = 0.35
    repetition_penalty = 1.0
    if template.stop_word is None:
        template.stop_word = tokenizer.eos_token
    stop_token_id = tokenizer.convert_tokens_to_ids(template.stop_word)

    history = []
    if lang_dir == "zh2en":
        query = f"Please translate the following paragraph from Chinese to English (only output translation results, no analysis): \nChinese: {text} \nEnglish:"
    elif lang_dir == "zh2el":
        query = f"Please translate the following paragraph from Chinese to Greek (only output translation results, no analysis): \nChinese: {text} \nGreek:"
    elif lang_dir == "zh2it":
        query = f"Please translate the following paragraph from Chinese to Italian (only output translation results, no analysis): \nChinese: {text} \nItalian:"
    elif lang_dir == "en2el":
        query = f"Please translate the following paragraph from English to Greek (only output translation results, no analysis): \nEnglish: {text} \nGreek:"
    elif lang_dir == "en2it":
        query = f"Please translate the following paragraph from English to Italian (only output translation results, no analysis): \nEnglish: {text} \nItalian:"
    
    input_ids = build_prompt(tokenizer, template, query, copy.deepcopy(history), system=None).to(model.device)
    outputs = model.generate(
        input_ids=input_ids, max_new_tokens=max_new_tokens, do_sample=True,
        top_p=top_p, temperature=temperature, repetition_penalty=repetition_penalty,
        eos_token_id=stop_token_id
    )
    outputs = outputs.tolist()[0][len(input_ids[0]):]
    response = tokenizer.decode(outputs)
    response = response.strip().replace(template.stop_word, "").strip()
    
    return response

def is_correct_language(ori_text, lang_dir):
    # 使用 langid 检测原始文本的语言
    detected_lang, _ = langid.classify(ori_text)
    
    # 根据 lang_dir 判断期望的语言
    if lang_dir.startswith('zh'):
        # 如果是中文语言目录，检查检测到的语言是否是中文
        return detected_lang == 'zh'
    elif lang_dir.startswith('en'):
        # 如果是英文语言目录，检查检测到的语言是否是英文
        return detected_lang == 'en'
    else:
        return False

def process_data(request_data: Dict[str, Any]) -> Dict[str, Any]:
    # 提取请求中的数据和翻译方向
    data = request_data.get("data", [])
    lang_dir = request_data.get("lang_dir", "")

    # 检测提供的翻译语向是否合适
    if lang_dir not in ['zh2en','zh2el','zh2it','en2el','en2it']:
        response_data = {"code": 500, "msg": "提供的待翻译语向错误！"}
        return response_data

    # 初始化返回的响应数据
    response_data = {"data": [], "code": 200, "msg": "数据增强成功"}

    # 遍历每个文本，进行翻译并添加到响应中
    for item in data:
        ori_text = item.get("ori_text", "")
        item_id = item.get("id")
        
        # 调用语种检测函数，检测输入的语种与翻译语向是否匹配
        # if not is_correct_language(ori_text,lang_dir):
        #     response_data = {"code": 500, "msg": "检测到源语言语向错误！"}
        #     return response_data
        # 调用翻译函数获取翻译结果
        trans_text = translate(ori_text, lang_dir)
        
        # 构建每个翻译项
        response_data["data"].append({
            "ori_text": ori_text,
            "trans_text": trans_text,
            "id": item_id
        })

    return response_data

