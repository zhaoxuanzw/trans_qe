from flask import Blueprint, request, jsonify
from .data_enhance_service import process_data,load_model # 导入翻译函数

data_enhance_bleuprint = Blueprint('data_enhance', __name__, url_prefix='/data_enhance')
load_model()
@data_enhance_bleuprint.route('/translation', methods=['POST'])
def translation_api():
    data = request.get_json()
    trans_txt = process_data(data)
    return jsonify(trans_txt)