# import nltk
# from nltk.translate.bleu_score import sentence_bleu, SmoothingFunction
# import jieba

# def calculate_nist(reference, candidate, max_n=4):
#     """
#     计算参考文本与候选文本之间的 NIST 分数。
#     """
#     smooth = SmoothingFunction().method4
#     nist_score = 0
#     for n in range(1, max_n + 1):
#         reference_ngrams = set(nltk.ngrams(jieba.lcut(reference), n))
#         candidate_ngrams = set(nltk.ngrams(jieba.lcut(candidate), n))
#         nist_score += sentence_bleu([reference_ngrams], candidate_ngrams, smoothing_function=smooth)
#     return nist_score / max_n

import jieba
import re
from nltk.translate.nist_score import sentence_nist

def is_chinese(text: str) -> bool:
    """
    判断文本是否包含中文字符。
    :param text: 输入文本。
    :return: 如果文本包含中文字符返回 True，否则返回 False。
    """
    return bool(re.search(r'[\u4e00-\u9fff]', text))

def calculate_nist(system_translation: str, reference_translation: list) -> float:
    """
    计算 NIST 分数，自动检测中文或英文文本并进行处理。
    :param system_translation: 系统翻译的字符串
    :param reference_translation: 参考翻译的列表（每个元素为一个翻译字符串）
    :return: NIST 得分
    """
    # 判断是否为中文文本
    if is_chinese(system_translation):
        # 中文文本使用 jieba 分词
        system_translation = list(jieba.cut(system_translation))
        reference_translation = [list(jieba.cut(ref)) for ref in reference_translation]
    else:
        # 英文文本按字符分割
        system_translation = list(system_translation)
        reference_translation = [list(ref) for ref in reference_translation]

    # 计算 NIST 分数
    nist_score = sentence_nist(reference_translation, system_translation)
    
    return nist_score
