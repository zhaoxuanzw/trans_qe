from flask import Blueprint, request, jsonify
from .nist_service import calculate_nist

# 创建 Blueprint 对象，URL 前缀为 /nist
nist_blueprint = Blueprint('nist', __name__, url_prefix='/nist')

@nist_blueprint.route('/calculate', methods=['POST'])
def calculate_nist_api():
    data = request.get_json()
    reference = data.get('reference')
    candidate = data.get('candidate')
    if not reference or not candidate:
        return jsonify({"error": "Both reference and candidate texts are required."}), 400
    nist_score = calculate_nist(candidate,[reference])
    return jsonify({"nist_score": nist_score})
