from flask import Blueprint, request, jsonify
from .comet_qe_service import compute_comet_qe_score  # 导入 COMET-QE 计算函数

# 创建 Blueprint 对象，URL 前缀为 /comet_qe
comet_qe_blueprint = Blueprint('comet_qe', __name__, url_prefix='/comet_qe')

@comet_qe_blueprint.route('/compute_comet_qe', methods=['POST'])
def compute_comet_qe_api():
    data = request.get_json()
    scores = compute_comet_qe_score(data)
    return jsonify({"comet_qe_scores": scores})
