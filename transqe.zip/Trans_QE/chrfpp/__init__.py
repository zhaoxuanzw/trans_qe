from flask import Blueprint, request, jsonify
from .chrfpp_service import compute_chrF_plus_plus

# 创建 Blueprint 对象，URL 前缀为 /chrfpp
chrfpp_blueprint = Blueprint('chrfpp', __name__, url_prefix='/chrfpp')

@chrfpp_blueprint.route('/calculate', methods=['POST'])
def calculate_chrF_plus_plus_api():
    data = request.get_json()
    reference = data.get('reference')
    hypothesis = data.get('hypothesis')

    if not reference or not hypothesis:
        return jsonify({"error": "Both reference and hypothesis texts are required."}), 400

    chrfpp_score = compute_chrF_plus_plus(reference, hypothesis)

    return jsonify({"chrF_plus_plus_score": chrfpp_score})
