import re
from collections import Counter

def compute_chrF_plus_plus(reference, hypothesis):
    """
    计算参考文本与候选文本之间的 chrF++ 分数。
    """
    def ngrams(tokens, n):
        return [tuple(tokens[i:i+n]) for i in range(len(tokens) - n + 1)]

    def char_ngrams(s, n):
        s = re.sub(r'\s', '', s)  # remove whitespace
        return ngrams(s, n)

    def compute_precision_recall(reference, hypothesis, n):
        ref_ngrams = char_ngrams(reference, n)
        hyp_ngrams = char_ngrams(hypothesis, n)

        ref_count = Counter(ref_ngrams)
        hyp_count = Counter(hyp_ngrams)

        intersection = ref_count & hyp_count

        precision = sum(intersection.values()) / max(sum(hyp_count.values()), 1)
        recall = sum(intersection.values()) / max(sum(ref_count.values()), 1)

        return precision, recall

    max_n = 7  # consider n-grams up to 7-grams
    weights = [0.05] * 6 + [0.4]  # weights for 1-gram to 7-gram

    avg_precision = 0.0
    avg_recall = 0.0

    for n in range(1, max_n + 1):
        precision, recall = compute_precision_recall(reference, hypothesis, n)
        avg_precision += precision * weights[n - 1]
        avg_recall += recall * weights[n - 1]

    if avg_precision + avg_recall > 0:
        chrF_score = 2 * avg_precision * avg_recall / (avg_precision + avg_recall)
    else:
        chrF_score = 0

    return chrF_score
