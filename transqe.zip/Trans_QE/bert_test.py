# from bert_score import score

# # 假设你有一组参考翻译和系统生成的翻译
# references = ["这是一个测试句子。", "你好，世界。"]
# candidates = ["这是一个测试。", "你好，世界！"]

# # 本地模型路径
# # local_model_path = "/home/master/xhj/Trans_QE/models/bert-base-chinese/"

# # 使用本地模型进行 BERT-score 计算
# P, R, F1 = score(candidates, references, model_type="bert-base-chinese", lang="zh")

# # 输出精度、召回率和F1得分
# for i in range(len(candidates)):
#     print(f"Candidate {i+1}:")
#     print(f"Precision: {P[i]:.4f}")
#     print(f"Recall: {R[i]:.4f}")
#     print(f"F1: {F1[i]:.4f}")


# from bert_score import score

# # 假设你有一组参考翻译和系统生成的翻译
# references = ["This is a test sentence.", "Hello world."]
# candidates = ["This is a test.", "Hello world!"]

# # 使用 roberta-large 模型进行 BERT-score 计算
# P, R, F1 = score(candidates, references, model_type="roberta-large", lang="en")

# # 输出精度、召回率和F1得分
# for i in range(len(candidates)):
#     print(f"Candidate {i+1}:")
#     print(f"Precision: {P[i]:.4f}")
#     print(f"Recall: {R[i]:.4f}")
#     print(f"F1: {F1[i]:.4f}")


# from bert_score import score

# # 假设你有一组参考翻译和系统生成的翻译（以法语为例）
# references = ["C'est une phrase de test.", "Bonjour le monde."]
# candidates = ["C'est une phrase.", "Bonjour tout le monde!"]

# # 使用 bert-base-multilingual-cased 模型进行 BERT-score 计算
# P, R, F1 = score(candidates, references, model_type="bert-base-multilingual-cased", lang="fr")

# # 输出精度、召回率和F1得分
# for i in range(len(candidates)):
#     print(f"Candidate {i+1}:")
#     print(f"Precision: {P[i]:.4f}")
#     print(f"Recall: {R[i]:.4f}")
#     print(f"F1: {F1[i]:.4f}")
import os
import sys
import time
import torch
from torch.nn.utils.rnn import pad_sequence
from tqdm.auto import tqdm
from transformers import AutoModel, AutoTokenizer

def greedy_cos_idf(
    ref_embedding,
    ref_masks,
    ref_idf,
    hyp_embedding,
    hyp_masks,
    hyp_idf,
    all_layers=False,
):
    """
    Compute greedy matching based on cosine similarity.

    Args:
        - :param: `ref_embedding` (torch.Tensor):
                   embeddings of reference sentences, BxKxd,
                   B: batch size, K: longest length, d: bert dimenison
        - :param: `ref_lens` (list of int): list of reference sentence length.
        - :param: `ref_masks` (torch.LongTensor): BxKxK, BERT attention mask for
                   reference sentences.
        - :param: `ref_idf` (torch.Tensor): BxK, idf score of each word
                   piece in the reference setence
        - :param: `hyp_embedding` (torch.Tensor):
                   embeddings of candidate sentences, BxKxd,
                   B: batch size, K: longest length, d: bert dimenison
        - :param: `hyp_lens` (list of int): list of candidate sentence length.
        - :param: `hyp_masks` (torch.LongTensor): BxKxK, BERT attention mask for
                   candidate sentences.
        - :param: `hyp_idf` (torch.Tensor): BxK, idf score of each word
                   piece in the candidate setence
    """
    ref_embedding.div_(torch.norm(ref_embedding, dim=-1).unsqueeze(-1))
    hyp_embedding.div_(torch.norm(hyp_embedding, dim=-1).unsqueeze(-1))

    if all_layers:
        B, _, L, D = hyp_embedding.size()
        hyp_embedding = (
            hyp_embedding.transpose(1, 2)
            .transpose(0, 1)
            .contiguous()
            .view(L * B, hyp_embedding.size(1), D)
        )
        ref_embedding = (
            ref_embedding.transpose(1, 2)
            .transpose(0, 1)
            .contiguous()
            .view(L * B, ref_embedding.size(1), D)
        )
    batch_size = ref_embedding.size(0)
    sim = torch.bmm(hyp_embedding, ref_embedding.transpose(1, 2))
    masks = torch.bmm(hyp_masks.unsqueeze(2).float(), ref_masks.unsqueeze(1).float())
    if all_layers:
        masks = masks.unsqueeze(0).expand(L, -1, -1, -1).contiguous().view_as(sim)
    else:
        masks = masks.expand(batch_size, -1, -1).contiguous().view_as(sim)

    masks = masks.float().to(sim.device)
    sim = sim * masks

    word_precision = sim.max(dim=2)[0]
    word_recall = sim.max(dim=1)[0]

    hyp_idf.div_(hyp_idf.sum(dim=1, keepdim=True))
    ref_idf.div_(ref_idf.sum(dim=1, keepdim=True))
    precision_scale = hyp_idf.to(word_precision.device)
    recall_scale = ref_idf.to(word_recall.device)
    if all_layers:
        precision_scale = (
            precision_scale.unsqueeze(0)
            .expand(L, B, -1)
            .contiguous()
            .view_as(word_precision)
        )
        recall_scale = (
            recall_scale.unsqueeze(0).expand(L, B, -1).contiguous().view_as(word_recall)
        )
    P = (word_precision * precision_scale).sum(dim=1)
    R = (word_recall * recall_scale).sum(dim=1)
    F = 2 * P * R / (P + R)

    hyp_zero_mask = hyp_masks.sum(dim=1).eq(2)
    ref_zero_mask = ref_masks.sum(dim=1).eq(2)

    if all_layers:
        P = P.view(L, B)
        R = R.view(L, B)
        F = F.view(L, B)

    if torch.any(hyp_zero_mask):
        print(
            "Warning: Empty candidate sentence detected; setting raw BERTscores to 0.",
            file=sys.stderr,
        )
        P = P.masked_fill(hyp_zero_mask, 0.0)
        R = R.masked_fill(hyp_zero_mask, 0.0)

    if torch.any(ref_zero_mask):
        print(
            "Warning: Empty reference sentence detected; setting raw BERTScores to 0.",
            file=sys.stderr,
        )
        P = P.masked_fill(ref_zero_mask, 0.0)
        R = R.masked_fill(ref_zero_mask, 0.0)

    F = F.masked_fill(torch.isnan(F), 0.0)

    return P, R, F

def sent_encode(tokenizer, sent):
    "Encoding as sentence based on the tokenizer"
    sent = sent.strip()  # 去除句子的前后空格
    if sent == "":
        return tokenizer.build_inputs_with_special_tokens([])  # 如果句子为空，返回空的 token 序列
    else:
        return tokenizer.encode(sent, add_special_tokens=True, truncation=True, max_length=tokenizer.model_max_length)  # 直接编码句子并添加特殊标记

def padding(arr, pad_token, dtype=torch.long):
    lens = torch.LongTensor([len(a) for a in arr])
    max_len = lens.max().item()
    padded = torch.ones(len(arr), max_len, dtype=dtype) * pad_token
    mask = torch.zeros(len(arr), max_len, dtype=torch.long)
    for i, a in enumerate(arr):
        padded[i, : lens[i]] = torch.tensor(a, dtype=dtype)
        mask[i, : lens[i]] = 1
    return padded, lens, mask

def collate_idf(arr, tokenizer, idf_dict, device="cuda:0"):
    """
    Helper function that pads a list of sentences to hvae the same length and
    loads idf score for words in the sentences.

    Args:
        - :param: `arr` (list of str): sentences to process.
        - :param: `tokenize` : a function that takes a string and return list
                  of tokens.
        - :param: `numericalize` : a function that takes a list of tokens and
                  return list of token indexes.
        - :param: `idf_dict` (dict): mapping a word piece index to its
                               inverse document frequency
        - :param: `pad` (str): the padding token.
        - :param: `device` (str): device to use, e.g. 'cpu' or 'cuda'
    """
    arr = [sent_encode(tokenizer, a) for a in arr]

    idf_weights = [[idf_dict[i] for i in a] for a in arr]

    pad_token = tokenizer.pad_token_id

    padded, lens, mask = padding(arr, pad_token, dtype=torch.long)
    padded_idf, _, _ = padding(idf_weights, 0, dtype=torch.float)

    padded = padded.to(device=device)
    mask = mask.to(device=device)
    lens = lens.to(device=device)
    return padded, padded_idf, lens, mask


def bert_encode(model, x, attention_mask, all_layers=False):
    model.eval()
    with torch.no_grad():
        out = model(x, attention_mask=attention_mask, output_hidden_states=all_layers)
    if all_layers:
        emb = torch.stack(out[-1], dim=2)
    else:
        emb = out[0]
    return emb

def get_bert_embedding(
    all_sens,
    model,
    tokenizer,
    idf_dict,
    batch_size=-1,
    device="cuda:0",
    all_layers=False,
):
    """
    Compute BERT embedding in batches.

    Args:
        - :param: `all_sens` (list of str) : sentences to encode.
        - :param: `model` : a BERT model from `pytorch_pretrained_bert`.
        - :param: `tokenizer` : a BERT tokenizer corresponds to `model`.
        - :param: `idf_dict` (dict) : mapping a word piece index to its
                               inverse document frequency
        - :param: `device` (str): device to use, e.g. 'cpu' or 'cuda'
    """

    padded_sens, padded_idf, lens, mask = collate_idf(
        all_sens, tokenizer, idf_dict, device=device
    )

    if batch_size == -1:
        batch_size = len(all_sens)

    embeddings = []
    with torch.no_grad():
        for i in range(0, len(all_sens), batch_size):
            batch_embedding = bert_encode(
                model,
                padded_sens[i : i + batch_size],
                attention_mask=mask[i : i + batch_size],
                all_layers=all_layers,
            )
            embeddings.append(batch_embedding)
            del batch_embedding

    total_embedding = torch.cat(embeddings, dim=0)

    return total_embedding, mask, padded_idf



def bert_cos_score_idf(
    model,
    refs,
    hyps,
    tokenizer,
    idf_dict,
    verbose=False,
    batch_size=64,
    device="cuda:0",
    all_layers=False,
):
    """
    Compute BERTScore.

    Args:
        - :param: `model` : a BERT model in `pytorch_pretrained_bert`
        - :param: `refs` (list of str): reference sentences
        - :param: `hyps` (list of str): candidate sentences
        - :param: `tokenzier` : a BERT tokenizer corresponds to `model`
        - :param: `idf_dict` : a dictionary mapping a word piece index to its
                               inverse document frequency
        - :param: `verbose` (bool): turn on intermediate status update
        - :param: `batch_size` (int): bert score processing batch size
        - :param: `device` (str): device to use, e.g. 'cpu' or 'cuda'
    """
    preds = []

    def dedup_and_sort(l):
        return sorted(list(set(l)), key=lambda x: len(x.split(" ")), reverse=True)

    sentences = dedup_and_sort(refs + hyps)
    embs = []
    iter_range = range(0, len(sentences), batch_size)
    if verbose:
        print("computing bert embedding.")
        iter_range = tqdm(iter_range)
    stats_dict = dict()
    for batch_start in iter_range:
        sen_batch = sentences[batch_start : batch_start + batch_size]
        embs, masks, padded_idf = get_bert_embedding(
            sen_batch, model, tokenizer, idf_dict, device=device, all_layers=all_layers
        )
        embs = embs.cpu()
        masks = masks.cpu()
        padded_idf = padded_idf.cpu()
        for i, sen in enumerate(sen_batch):
            sequence_len = masks[i].sum().item()
            emb = embs[i, :sequence_len]
            idf = padded_idf[i, :sequence_len]
            stats_dict[sen] = (emb, idf)

    def pad_batch_stats(sen_batch, stats_dict, device):
        stats = [stats_dict[s] for s in sen_batch]
        emb, idf = zip(*stats)
        emb = [e.to(device) for e in emb]
        idf = [i.to(device) for i in idf]
        lens = [e.size(0) for e in emb]
        emb_pad = pad_sequence(emb, batch_first=True, padding_value=2.0)
        idf_pad = pad_sequence(idf, batch_first=True)

        def length_to_mask(lens):
            lens = torch.tensor(lens, dtype=torch.long)
            max_len = max(lens)
            base = torch.arange(max_len, dtype=torch.long).expand(len(lens), max_len)
            return base < lens.unsqueeze(1)

        pad_mask = length_to_mask(lens).to(device)
        return emb_pad, pad_mask, idf_pad

    device = next(model.parameters()).device
    iter_range = range(0, len(refs), batch_size)
    if verbose:
        print("computing greedy matching.")
        iter_range = tqdm(iter_range)

    with torch.no_grad():
        for batch_start in iter_range:
            batch_refs = refs[batch_start : batch_start + batch_size]
            batch_hyps = hyps[batch_start : batch_start + batch_size]
            ref_stats = pad_batch_stats(batch_refs, stats_dict, device)
            hyp_stats = pad_batch_stats(batch_hyps, stats_dict, device)

            P, R, F1 = greedy_cos_idf(*ref_stats, *hyp_stats, all_layers)
            preds.append(torch.stack((P, R, F1), dim=-1).cpu())
    preds = torch.cat(preds, dim=1 if all_layers else 0)
    return preds

from transformers import AutoModel

def get_model(model_type, num_layers):
    if model_type not in ["roberta-large", "bert-base-chinese", "bert-base-multilingual-cased"]:
        raise ValueError(f"Unsupported model: {model_type}")
    
    model = AutoModel.from_pretrained(model_type)
    model.eval()

    # 根据 num_layers 裁剪层数
    if hasattr(model, "encoder"):
        layers = model.encoder.layer
    else:  # For roberta
        layers = model.transformer.layer

    assert 0 <= num_layers <= len(layers), f"Invalid num_layers: should be between 0 and {len(layers)}"
    model.encoder.layer = torch.nn.ModuleList(layers[:num_layers])

    return model

class DefaultDictLike:
    def __init__(self, default_factory):
        """初始化时传入默认工厂函数"""
        self.default_factory = default_factory
        self.store = {}

    def __getitem__(self, key):
        """重载访问字典元素时的行为"""
        if key not in self.store:
            self.store[key] = self.default_factory()  # 使用默认工厂函数创建默认值
        return self.store[key]

    def __setitem__(self, key, value):
        """设置字典元素的值"""
        self.store[key] = value

    def get(self, key, default=None):
        """获取字典元素的值，支持默认值"""
        if key not in self.store:
            return default
        return self.store[key]

    def __contains__(self, key):
        """检查字典中是否包含指定的键"""
        return key in self.store

    def __repr__(self):
        return repr(self.store)

def create_default_dict(default_factory):
    return DefaultDictLike(default_factory)

def main():
    # model_path = ""
    model_type = "roberta-large"
    tokenizer = tokenizer = AutoTokenizer.from_pretrained(model_type, use_fast=False)
    model2layers = {
        "roberta-large": 17,
        "bert-base-chinese": 8,
        "bert-base-multilingual-cased": 9,
    }
    num_layers = model2layers[model_type]
    model = get_model(model_type, num_layers)
    
    device = "cuda" if torch.cuda.is_available() else "cpu"
    model.to(device)
    

    refs = ["This is a test sentence.", "Hello world."]
    cands = ["This is a test.", "Hello world!"]

    idf_dict = create_default_dict(lambda: 1.0)
    # set idf for [SEP] and [CLS] to 0
    idf_dict[tokenizer.sep_token_id] = 0
    idf_dict[tokenizer.cls_token_id] = 0

    all_preds = bert_cos_score_idf(
        model,
        refs,
        cands,
        tokenizer,
        idf_dict=idf_dict,  # 不传入IDF字典
        verbose=False,
        device=device,
        batch_size=64,
        all_layers=False,
    ).cpu()

    # 返回精度、召回率、F1
    out = all_preds[..., 0], all_preds[..., 1], all_preds[..., 2]  # P, R, F
    print(out)
    # return out


if __name__ == '__main__':
    main()