from flask import Blueprint, request, jsonify
from .comet_kiwi_service import compute_comet_kiwi_score  # 导入 COMET-kiwi 计算函数

# 创建 Blueprint 对象，URL 前缀为 /comet_kiwi
comet_kiwi_blueprint = Blueprint('comet_kiwi', __name__, url_prefix='/comet_kiwi')

@comet_kiwi_blueprint.route('/compute_comet_kiwi', methods=['POST'])
def compute_cometkiwi_api():
    data = request.get_json()
    scores = compute_comet_kiwi_score(data)
    return jsonify({"comet_kiwi_scores": scores})
