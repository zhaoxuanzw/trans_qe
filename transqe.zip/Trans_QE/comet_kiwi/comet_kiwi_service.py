import os
os.environ["CUDA_VISIBLE_DEVICES"] = "0"  # 设置使用显卡

from comet import download_model, load_from_checkpoint

# 加载模型
# model_path = download_model("Unbabel/wmt22-cometkiwi-da")
model_path = "models/wmt22-cometkiwi-da/checkpoints/model.ckpt"
comet_model = load_from_checkpoint(model_path)

def compute_comet_kiwi_score(data):
    # 使用加载的模型计算 COMET-QE 分数
    prediction = comet_model.predict(data, batch_size=32, gpus=1)
    return prediction.scores  # 提取得分
