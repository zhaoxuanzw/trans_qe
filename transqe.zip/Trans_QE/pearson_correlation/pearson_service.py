import numpy as np

def calculate_pearson_correlation(manual_scores, machine_scores):
    """
    计算人工评分和机器评分之间的皮尔森系数。

    参数:
    manual_scores -- 人工评分的列表
    machine_scores -- 机器评分的列表

    返回:
    pearson_coefficient -- 皮尔森系数，或错误信息字典
    """
    if len(manual_scores) < 1:
        return {"error": "人工评分列表不能为空"}, 400
    if len(machine_scores) < 2:
        return {"error": "机器评分列表长度至少需要为2"}, 400

    try:
        # 如果 manual_scores 只有一个值，根据 machine_scores 的长度扩展
        if len(manual_scores) == 1:
            manual_scores = [manual_scores[0]] * len(machine_scores)

        # 将数据转换为 numpy 数组
        manual_scores_np = np.array(manual_scores, dtype=float)
        machine_scores_np = np.array(machine_scores, dtype=float)

        # 检查数据中是否存在非数值类型（比如 None 等情况），如果有则返回错误提示
        if np.isnan(manual_scores_np).any() or np.isnan(machine_scores_np).any():
            return {"error": "人工评分和机器评分数据中不能包含非数值类型"}, 400

        # 分别计算人工评分和机器评分的标准差，并检查是否为 0
        manual_std = np.std(manual_scores_np)
        machine_std = np.std(machine_scores_np)

        # 如果人工评分的标准差为 0，直接返回错误提示
        if manual_std == 0:
            return {"error": "人工评分数据的标准差为 0，无法计算皮尔森系数，请确保人工评分有足够的变化幅度"}, 400

        # 如果机器评分的标准差为 0，返回错误提示
        if machine_std == 0:
            return {"error": "机器评分数据的标准差为 0，无法计算皮尔森系数，请确保机器评分有足够的变化幅度"}, 400

        # 计算皮尔森系数
        coefficient = np.corrcoef(manual_scores_np, machine_scores_np)[0, 1]
        return coefficient
    except Exception as e:
        print(f"计算皮尔森系数时出错: {e}")
        return {"error": "计算皮尔森系数出现内部错误"}, 500
