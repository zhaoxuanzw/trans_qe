from flask import Blueprint, request, jsonify
from .pearson_service import calculate_pearson_correlation

# 创建 Blueprint 对象，URL 前缀为 /pearson
pearson_blueprint = Blueprint('pearson', __name__, url_prefix='/pearson')

@pearson_blueprint.route('/calculate_pearson', methods=['POST'])
def calculate_pearson_api():
    """
    接收 POST 请求并计算皮尔森系数。
    期望请求体为 JSON 格式，包含 `manual_scores`、`machine_scores` 和 `machine_type` 字段。
    """
    try:
        data = request.get_json()

        # 获取人工评分、机器评分和机器类型数据
        manual_scores = data.get('manual_scores', [])
        machine_scores = data.get('machine_scores', [])
        machine_type = data.get('machine_type', [])

        if not manual_scores or not machine_scores or not machine_type:
            return jsonify({"error": "必须提供 `manual_scores`、`machine_scores` 和 `machine_type`"}), 400

        # 计算皮尔森系数
        pearson_result = calculate_pearson_correlation(manual_scores, machine_scores)

        # 如果返回的是错误信息字典（例如计算失败）
        if isinstance(pearson_result, tuple) and len(pearson_result) == 2:
            return jsonify(pearson_result[0]), pearson_result[1]

        # 构建包含机器类型和皮尔森系数的结果字典，这里以列表形式返回多个机器类型对应的结果
        results = []
        for m_type in machine_type:
            result_dict = {
                "machine_type": m_type,
                "pearson_coefficient": pearson_result
            }
            results.append(result_dict)

        return jsonify(results)

    except Exception as e:
        return jsonify({"error": f"请求处理失败: {e}"}), 500
