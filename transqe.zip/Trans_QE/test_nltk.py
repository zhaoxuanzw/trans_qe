# import jieba
# import re
# from nltk.translate.nist_score import sentence_nist

# def is_chinese(text: str) -> bool:
#     """
#     判断文本是否包含中文字符。
#     :param text: 输入文本。
#     :return: 如果文本包含中文字符返回 True，否则返回 False。
#     """
#     return bool(re.search(r'[\u4e00-\u9fff]', text))

# def calculate_nist(system_translation: str, reference_translation: list) -> float:
#     """
#     计算 NIST 分数，自动检测中文或英文文本并进行处理。
#     :param system_translation: 系统翻译的字符串
#     :param reference_translation: 参考翻译的列表（每个元素为一个翻译字符串）
#     :return: NIST 得分
#     """
#     # 判断是否为中文文本
#     if is_chinese(system_translation):
#         # 中文文本使用 jieba 分词
#         system_translation = list(jieba.cut(system_translation))
#         reference_translation = [list(jieba.cut(ref)) for ref in reference_translation]
#     else:
#         # 英文文本按字符分割
#         system_translation = list(system_translation)
#         reference_translation = [list(ref) for ref in reference_translation]

#     # 计算 NIST 分数
#     nist_score = sentence_nist(reference_translation, system_translation)
    
#     return nist_score

# # 示例调用
# system_translation_en = "It is a guide to action which ensures that the military always obeys the commands of the party"
# reference_translation_en = [
#     "It is a guide to action that ensures that the military will forever heed Party commands",
#     "It is a guide to action that ensures that the military will always obey Party commands"
# ]

# nist_score_en = calculate_nist(system_translation_en, reference_translation_en)
# print(f"英文 NIST 分数: {nist_score_en:.4f}")

# system_translation_zh = "这是一本确保军事永远听从党的指挥的行动指南"
# reference_translation_zh = [
#     "这是一本确保军事会永远听从党的命令的指南",
#     "这是一本确保军队将永远服从党的指挥的指南"
# ]

# nist_score_zh = calculate_nist(system_translation_zh, reference_translation_zh)
# print(f"中文 NIST 分数: {nist_score_zh:.4f}")

import sacrebleu

# 参考翻译（多个参考句子）
references = [
    "It is a guide to action that ensures that the military will forever heed Party commands."
]

# 机器翻译结果（假设已经是分词后的列表）
hypothesis = "It is a guide to action which ensures that the military always obeys the commands of the party."

# 计算 TER 分数
ter_score = sacrebleu.corpus_ter([hypothesis], [references])

print(f"TER Score: {ter_score.score:.4f}")
