from flask import Blueprint, request, jsonify
from .nltk_bleu_service import calculate_bleu

# 创建 Blueprint 对象，URL 前缀为 /nltk_bleu
nltk_bleu_blueprint = Blueprint('nltk_bleu', __name__, url_prefix='/nltk_bleu')

@nltk_bleu_blueprint.route('/calculate', methods=['POST'])
def calculate_bleu_api():
    data = request.get_json()
    reference = data.get('reference')
    candidate = data.get('candidate')
    if not reference or not candidate:
        return jsonify({"error": "Both reference and candidate texts are required."}), 400
    bleu_score = calculate_bleu(reference, candidate)
    return jsonify({"bleu_score": bleu_score})
