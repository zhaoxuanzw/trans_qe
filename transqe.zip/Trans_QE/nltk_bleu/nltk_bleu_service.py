from nltk.translate.bleu_score import sentence_bleu, SmoothingFunction
import jieba

def calculate_bleu(reference, candidate):
    """
    计算参考文本与候选文本之间的 BLEU 分数。
    """
    smooth = SmoothingFunction().method4
    reference_tokens = jieba.lcut(reference)
    candidate_tokens = jieba.lcut(candidate)
    score = sentence_bleu([reference_tokens], candidate_tokens, smoothing_function=smooth)
    return score
