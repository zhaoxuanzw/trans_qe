

import torch
from transformers import AutoTokenizer
from .bert_utils import get_model, bert_cos_score_idf, create_default_dict

# 全局变量保存模型和tokenizer
models = {}
tokenizers = {}

def load_models():
    global models, tokenizers
    model_types = ["roberta-large", "bert-base-chinese", "bert-base-multilingual-cased"]
    model_paths = {
        "roberta-large":"../models/models--roberta-large",
        "bert-base-chinese":"../models/models--bert-base-chinese",
        "bert-base-multilingual-cased":"../models/models--bert-base-multilingual-cased"
    }
    #如果将路径复制过去后出错，尝试使用本地路径加载模型，即替换22行和30行的注释代码
    for model_type in model_types:
        tokenizer = AutoTokenizer.from_pretrained(model_type, use_fast=False)
        # tokenizer = AutoTokenizer.from_pretrained(model_paths[model_type], use_fast=False)
        model2layers = {
            "roberta-large": 17,
            "bert-base-chinese": 8,
            "bert-base-multilingual-cased": 9,
        }
        num_layers = model2layers.get(model_type, 17)
        model = get_model(model_type, num_layers)
        # model = get_model(model_paths[model_type], num_layers)
        device = "cuda" if torch.cuda.is_available() else "cpu"
        model.to(device)
        
        # 存储模型和tokenizer
        models[model_type] = model
        tokenizers[model_type] = tokenizer

def compute_bert_cos_score(data):
    # 如果模型还没加载，则提前加载
    if not models or not tokenizers:
        load_models()
    print(data)
    model_type = data.get("model_type", "roberta-large")
    refs = data.get("refs", [])
    cands = data.get("cands", [])
    
    if model_type not in models:
        raise ValueError(f"Unsupported model type: {model_type}")

    model = models[model_type]
    tokenizer = tokenizers[model_type]

    idf_dict = create_default_dict(lambda: 1.0)
    # 设置 [SEP] 和 [CLS] 的 IDF 为 0
    idf_dict[tokenizer.sep_token_id] = 0
    idf_dict[tokenizer.cls_token_id] = 0

    device = "cuda" if torch.cuda.is_available() else "cpu"

    all_preds = bert_cos_score_idf(
        model,
        refs,
        cands,
        tokenizer,
        idf_dict=idf_dict,  # 你可以选择是否传入IDF字典
        verbose=False,
        device=device,
        batch_size=64,
        all_layers=False,
    ).cpu()

    # 返回精度、召回率和F1
    out = all_preds[..., 0], all_preds[..., 1], all_preds[..., 2]  # P, R, F
    return out

