# ./bert_score/__init__.py
from flask import Blueprint, request, jsonify
from .bert_score_service import compute_bert_cos_score,load_models



# 创建 Blueprint 对象，URL 前缀为 /bert_score
bert_score_blueprint = Blueprint('bert_score', __name__, url_prefix='/bert_score')
load_models()

@bert_score_blueprint.route('/compute_bert_score', methods=['POST'])
def compute_bert_score_api():
    data = request.get_json()
    scores = compute_bert_cos_score(data)
    return jsonify({
        "precision": scores[0].tolist(),  # 转换为列表，以便JSON响应
        "recall": scores[1].tolist(),
        "f1": scores[2].tolist()
    })