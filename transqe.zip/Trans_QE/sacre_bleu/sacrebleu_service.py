import sacrebleu
from flask import jsonify, request
import langid
import jieba

def calculate_sacrebleu_zh(reference, translation):
    # 对参考译文和机器译文进行分词处理
    reference_tokens = " ".join(jieba.cut(reference))  # 用空格连接分词结果
    translation_tokens = " ".join(jieba.cut(translation))  # 用空格连接分词结果

    # 将分词后的结果包装成列表
    references = [reference_tokens]  # 参考译文列表
    translations = [translation_tokens]  # 机器翻译列表

    # 计算 BLEU 分数
    score = sacrebleu.corpus_bleu(translations, [references])

    return score.score  # 返回 BLEU 分数


def calculate_sacrebleu_other(reference, translation):
    # 将参考译文和机器译文包装成列表
    references = [reference]
    translations = [translation]

    # 计算 BLEU 分数
    score = sacrebleu.corpus_bleu(translations, [references])

    return score.score


# 根据语言检测选择计算 BLEU 的函数
def calculate_sacrebleu(reference, translation):
    # 检测语言
    lang, _ = langid.classify(reference)

    # 如果是中文，调用中文 BLEU 计算函数
    if lang == 'zh':
        return calculate_sacrebleu_zh(reference, translation)
    else:
        return calculate_sacrebleu_other(reference, translation)
