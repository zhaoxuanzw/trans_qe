from flask import Blueprint, request, jsonify
from .sacrebleu_service import calculate_sacrebleu  # 导入 sacrebleu 计算函数

# 创建 Blueprint 对象，URL 前缀为 /sacrebleu
sacrebleu_blueprint = Blueprint('sacrebleu', __name__, url_prefix='/sacrebleu')

@sacrebleu_blueprint.route('/calculate', methods=['POST'])
def calculate_sacrebleu_api():
    data = request.get_json()
    reference = data.get('reference')
    candidate = data.get('candidate')
    if not reference or not candidate:
        return jsonify({"error": "Both reference and candidate texts are required."}), 400
    sacrebleu_score = calculate_sacrebleu(reference, candidate)
    return jsonify({"sacrebleu_score": sacrebleu_score})
