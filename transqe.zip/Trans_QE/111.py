import torch

# 检查 PyTorch 版本
print("PyTorch version:", torch.__version__)

# 检查 CUDA 是否可用
cuda_available = torch.cuda.is_available()
print("Is CUDA available:", cuda_available)

if cuda_available:
    # 检查当前使用的 GPU 名称
    print("Current GPU device:", torch.cuda.get_device_name(0))

    # 检查 CUDA 的版本
    print("CUDA version:", torch.version.cuda)

    # 测试张量计算是否可以在 GPU 上运行
    x = torch.rand(3, 3).cuda()  # 在 GPU 上创建一个随机张量
    y = torch.rand(3, 3).cuda()  # 再创建一个随机张量
    z = x + y  # 执行张量加法
    print("Tensor calculation on GPU successful. Result:\n", z)

# 测试张量计算（在 CPU 上）
x = torch.rand(3, 3)
y = torch.rand(3, 3)
z = x + y
print("Tensor calculation on CPU successful. Result:\n", z)
