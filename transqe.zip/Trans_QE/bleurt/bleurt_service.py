import torch
from bleurt_pytorch import BleurtConfig, BleurtForSequenceClassification, BleurtTokenizer

# 加载模型和 Tokenizer
model_path = "models/BLEURT-20"
config = BleurtConfig.from_pretrained(model_path)
model = BleurtForSequenceClassification.from_pretrained(model_path)
tokenizer = BleurtTokenizer.from_pretrained(model_path)

def compute_bleurt_score(data):
    """
    接收 data，计算 BLEURT 分数。
    data 应该是一个包含 "references" 和 "candidates" 字段的字典。
    """
    references = [item['ref'] for item in data['data']]
    candidates = [item['mt'] for item in data['data']]
    
    # 将模型设置为评估模式
    model.eval()
    
    with torch.no_grad():
        # 将参考和候选句子进行编码
        inputs = tokenizer(references, candidates, padding='longest', return_tensors='pt')
        
        # 获取模型输出，并提取分数
        res = model(**inputs).logits.flatten().tolist()
    
    return res
