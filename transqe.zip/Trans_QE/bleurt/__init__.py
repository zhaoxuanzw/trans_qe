from flask import Blueprint, request, jsonify
from .bleurt_service import compute_bleurt_score  # 导入 BLEURT 计算函数

# 创建 Blueprint 对象，URL 前缀为 /bleurt
bleurt_blueprint = Blueprint('bleurt', __name__, url_prefix='/bleurt')

@bleurt_blueprint.route('/compute_bleurt', methods=['POST'])
def compute_bleurt_api():
    data = request.get_json()
    scores = compute_bleurt_score(data)
    return jsonify({"bleurt_scores": scores})
