# ./comet_da/__init__.py
from flask import Blueprint, request, jsonify
from .comet_da_service import compute_comet_da_score  # 导入 COMET 计算函数

# 创建 Blueprint 对象，URL 前缀为 /comet_da
comet_da_blueprint = Blueprint('comet_da', __name__, url_prefix='/comet_da')

@comet_da_blueprint.route('/compute_comet_da', methods=['POST'])
def compute_comet_da_api():
    data = request.get_json()
    scores = compute_comet_da_score(data)
    return jsonify({"comet_da_scores": scores})
